import logging
import asyncio
import time
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from config import DEVELOPER
from fonts import transform_text
from languages import search_country, COUNTRIES
from keyboards import get_font_keyboard, get_language_keyboard, get_main_keyboard

logger = logging.getLogger(__name__)

# Store user data
user_data = {}
#bndevloper
# Translation cache with timestamp
translation_cache = {}
cache_timeout = 300  # 5 minutes cache

# Rate limiting
last_translation_time = 0
min_interval = 2  # 2 seconds between translations

# Supported languages with correct codes
SUPPORTED_LANGUAGES = {
    'en': 'English',
    'hi': 'Hindi',
    'es': 'Spanish',
    'fr': 'French',
    'de': 'German',
    'it': 'Italian',
    'pt': 'Portuguese',
    'ru': 'Russian',
    'ja': 'Japanese',
    'zh-CN': 'Chinese',
    'ko': 'Korean',
    'ar': 'Arabic',
    'tr': 'Turkish',
    'nl': 'Dutch',
    'pl': 'Polish',
    'sv': 'Swedish',
    'no': 'Norwegian',
    'da': 'Danish',
    'fi': 'Finnish',
    'el': 'Greek',
    'he': 'Hebrew',
    'th': 'Thai',
    'vi': 'Vietnamese',
    'id': 'Indonesian',
    'ms': 'Malay',
    'tl': 'Filipino',
    'ur': 'Urdu',
    'bn': 'Bengali',
    'si': 'Sinhala',
    'ne': 'Nepali',
    'uk': 'Ukrainian',
    'cs': 'Czech',
    'hu': 'Hungarian',
    'ro': 'Romanian',
    'bg': 'Bulgarian',
    'hr': 'Croatian',
    'sk': 'Slovak',
    'sl': 'Slovenian',
    'lt': 'Lithuanian',
    'lv': 'Latvian',
    'et': 'Estonian',
    'is': 'Icelandic',
    'mt': 'Maltese',
    'sq': 'Albanian',
    'mk': 'Macedonian',
    'be': 'Belarusian',
    'hy': 'Armenian',
    'az': 'Azerbaijani',
    'kk': 'Kazakh',
    'uz': 'Uzbek',
}

async def translate_text(text, target_lang):
    """Translate text with rate limiting and caching"""
    global last_translation_time
    
    cache_key = f"{text}_{target_lang}"
    
    # Check cache first
    if cache_key in translation_cache:
        cached_data = translation_cache[cache_key]
        if time.time() - cached_data['timestamp'] < cache_timeout:
            return cached_data['result']
    
    # Rate limiting
    current_time = time.time()
    time_since_last = current_time - last_translation_time
    if time_since_last < min_interval:
        wait_time = min_interval - time_since_last
        await asyncio.sleep(wait_time)
    
    # Check if language is supported
    if target_lang not in SUPPORTED_LANGUAGES:
        logger.warning(f"Language {target_lang} not supported")
        return None
    
    try:
        # Try Google Translate
        from deep_translator import GoogleTranslator
        translator = GoogleTranslator(source='auto', target=target_lang)
        result = translator.translate(text)
        
        if result and result != text:
            # Cache the result
            translation_cache[cache_key] = {
                'result': result,
                'timestamp': time.time()
            }
            last_translation_time = time.time()
            return result
            
    except Exception as e:
        logger.error(f"Google translation error for {target_lang}: {e}")
        
        # Try LibreTranslate as fallback (if supported)
        try:
            import aiohttp
            url = "https://libretranslate.com/translate"
            payload = {
                "q": text,
                "source": "auto",
                "target": target_lang,
                "format": "text"
            }
            
            timeout = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post(url, json=payload) as response:
                    if response.status == 200:
                        data = await response.json()
                        result = data.get("translatedText", text)
                        if result and result != text:
                            translation_cache[cache_key] = {
                                'result': result,
                                'timestamp': time.time()
                            }
                            last_translation_time = time.time()
                            return result
        except Exception as e2:
            logger.error(f"LibreTranslate error for {target_lang}: {e2}")
    
    return None

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /start command"""
    user = update.effective_user
    await update.message.reply_text(
        f"👋 Welcome {user.first_name}!\n\n"
        "Send any text or use buttons below:\n\n"
        "🎨 FRONTTXT - Change text style\n"
        "🌍 LANGUAGE - Translate to any language\n"
        "👨‍💻 DEVELOPER - Contact developer",
        reply_markup=get_main_keyboard()
    )

async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle user text messages"""
    user_id = update.effective_user.id
    user_text = update.message.text
    chat_id = update.effective_chat.id
    
    if user_id not in user_data:
        user_data[user_id] = {}
    
    # Store text
    user_data[user_id]['last_text'] = user_text
    user_data[user_id]['chat_id'] = chat_id
    user_data[user_id]['current_page'] = 0
    user_data[user_id]['lang_page'] = 0
    user_data[user_id]['current_mode'] = 'font'
    
    # Check what mode user is in
    mode = user_data[user_id].get('mode', 'font')
    
    if mode == 'font':
        # Show font options
        reply_markup = get_font_keyboard(0)
        msg = await update.message.reply_text(
            user_text,
            reply_markup=reply_markup
        )
        user_data[user_id]['bot_msg_id'] = msg.message_id
        user_data[user_id]['current_keyboard'] = reply_markup
    elif mode == 'language':
        # Show language options
        reply_markup = get_language_keyboard(0)
        msg = await update.message.reply_text(
            user_text,
            reply_markup=reply_markup
        )
        user_data[user_id]['bot_msg_id'] = msg.message_id
        user_data[user_id]['current_keyboard'] = reply_markup

async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle all button callbacks"""
    query = update.callback_query
    data = query.data
    user_id = update.effective_user.id
    
    if user_id not in user_data:
        user_data[user_id] = {}
    
    # Main menu button - Go back to main menu
    if data == "menu_main":
        user_data[user_id]['mode'] = 'font'
        user_data[user_id]['current_page'] = 0
        user_data[user_id]['lang_page'] = 0
        await query.edit_message_text(
            "🏠 **Main Menu**\n\n"
            "Choose an option below:\n\n"
            "🎨 FRONTTXT - Change text style\n"
            "🌍 LANGUAGE - Translate to any language\n"
            "👨‍💻 DEVELOPER - Contact developer",
            reply_markup=get_main_keyboard()
        )
        await query.answer()
        return
    
    # Main menu buttons
    if data == "menu_font":
        user_data[user_id]['mode'] = 'font'
        user_data[user_id]['current_page'] = 0
        await query.edit_message_text(
            "📝 **Send your text!**\n\n"
            "Type any message and send it to me.\n"
            "I'll show you font options to change its style.",
            reply_markup=get_main_keyboard()
        )
        await query.answer()
        return
    
    elif data == "menu_language":
        user_data[user_id]['mode'] = 'language'
        user_data[user_id]['lang_page'] = 0
        await query.edit_message_text(
            "🌍 **Send your text!**\n\n"
            "Type any message and send it to me.\n"
            "I'll translate it to your chosen language.",
            reply_markup=get_main_keyboard()
        )
        await query.answer()
        return
    
    elif data == "menu_developer":
        await query.edit_message_text(
            f"👨‍💻 **Developer**\n\n"
            f"Contact: {DEVELOPER}\n\n"
            f"Bot by BNDEV ❤️",
            reply_markup=get_main_keyboard()
        )
        await query.answer()
        return
    
    # Font page navigation
    if data.startswith("font_page_"):
        page = int(data.split("_")[2])
        user_data[user_id]['current_page'] = page
        await show_font_menu(update, context, user_id)
        return
    
    # Language page navigation
    if data.startswith("lang_page_"):
        page = int(data.split("_")[2])
        user_data[user_id]['lang_page'] = page
        await show_language_menu(update, context, user_id)
        return
    
    # Font selection
    if data.startswith("font_"):
        style = data.split("_")[1]
        original_text = user_data[user_id].get('last_text', '')
        transformed = transform_text(original_text, style)
        
        chat_id = user_data[user_id].get('chat_id')
        bot_msg_id = user_data[user_id].get('bot_msg_id')
        current_page = user_data[user_id].get('current_page', 0)
        
        # Get stored keyboard or create new
        reply_markup = get_font_keyboard(current_page)
        user_data[user_id]['current_keyboard'] = reply_markup
        
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=bot_msg_id,
                text=transformed,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Font edit error: {e}")
        
        await query.answer()
        return
    
    # Language selection - Translate the text
    if data.startswith("lang_"):
        code = data.split("_")[1]
        original_text = user_data[user_id].get('last_text', '')
        
        # Find country
        country = None
        for c in COUNTRIES:
            if c['code'] == code:
                country = c
                break
        
        if country and original_text:
            # Check cache first for immediate response
            cache_key = f"{original_text}_{code}"
            cached_result = None
            
            if cache_key in translation_cache:
                cached_data = translation_cache[cache_key]
                if time.time() - cached_data['timestamp'] < cache_timeout:
                    cached_result = cached_data['result']
            
            if cached_result:
                # Use cached result immediately
                transformed = cached_result
            else:
                try:
                    # Check if language is supported
                    if code not in SUPPORTED_LANGUAGES:
                        logger.warning(f"Language {code} not supported, showing original")
                        transformed = original_text
                    else:
                        # Translate with rate limiting
                        translated = await translate_text(original_text, code)
                        
                        if translated and translated != original_text:
                            transformed = translated
                        else:
                            transformed = original_text
                except Exception as e:
                    logger.error(f"Translation error: {e}")
                    transformed = original_text
        else:
            transformed = original_text
        
        chat_id = user_data[user_id].get('chat_id')
        bot_msg_id = user_data[user_id].get('bot_msg_id')
        lang_page = user_data[user_id].get('lang_page', 0)
        
        # Get stored keyboard or create new
        reply_markup = get_language_keyboard(lang_page)
        user_data[user_id]['current_keyboard'] = reply_markup
        
        try:
            # Edit ONLY text, keep buttons exactly as they are
            await context.bot.edit_message_text(
                chat_id=chat_id,
                message_id=bot_msg_id,
                text=transformed,
                reply_markup=reply_markup
            )
        except Exception as e:
            logger.error(f"Language edit error: {e}")
        
        await query.answer()
        return

async def show_font_menu(update, context, user_id):
    """Show font selection menu"""
    query = update.callback_query
    current_page = user_data[user_id].get('current_page', 0)
    text = user_data[user_id].get('last_text', 'Your text')
    
    reply_markup = get_font_keyboard(current_page)
    user_data[user_id]['current_keyboard'] = reply_markup
    
    await query.edit_message_text(
        text,
        reply_markup=reply_markup
    )
    await query.answer()

async def show_language_menu(update, context, user_id):
    """Show language selection menu"""
    query = update.callback_query
    lang_page = user_data[user_id].get('lang_page', 0)
    text = user_data[user_id].get('last_text', '')
    
    reply_markup = get_language_keyboard(lang_page)
    user_data[user_id]['current_keyboard'] = reply_markup
    
    await query.edit_message_text(
        text,
        reply_markup=reply_markup
    )
    await query.answer()

async def search_language(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Search for a language by name"""
    query = ' '.join(context.args) if context.args else ''
    user_id = update.effective_user.id
    
    if user_id not in user_data:
        user_data[user_id] = {}
    
    if not query:
        await update.message.reply_text(
            "🔍 **Search Language**\n\n"
            "Usage: /search <language_name>\n"
            "Example: /search hindi\n\n"
            "First send your text, then search for language to translate!"
        )
        return
    
    results = search_country(query)
    
    if not results:
        await update.message.reply_text(f"❌ No language found for: {query}")
        return
    
    user_data[user_id]['chat_id'] = update.effective_chat.id
    
    # Show search results
    keyboard = []
    row = []
    for country in results[:10]:
        display = f"{country['flag']} {country['name']}"
        row.append(InlineKeyboardButton(display, callback_data=f"lang_{country['code']}"))
        if len(row) == 2:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    keyboard.append([InlineKeyboardButton("🔙 Back to Menu", callback_data="menu_language")])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    msg = await update.message.reply_text(
        f"🔍 **Search Results for: {query}**\n\n"
        f"Found {len(results)} results. Click to translate:",
        reply_markup=reply_markup
    )
    
    user_data[user_id]['bot_msg_id'] = msg.message_id
    user_data[user_id]['current_keyboard'] = reply_markup
