# Country/Language Data with Flags and Correct Codes  ook bro free ha 

COUNTRIES = [
    {"flag": "🇺🇸", "name": "English", "code": "en"},
    {"flag": "🇮🇳", "name": "Hindi", "code": "hi"},
    {"flag": "🇪🇸", "name": "Spanish", "code": "es"},
    {"flag": "🇫🇷", "name": "French", "code": "fr"},
    {"flag": "🇩🇪", "name": "German", "code": "de"},
    {"flag": "🇮🇹", "name": "Italian", "code": "it"},
    {"flag": "🇵🇹", "name": "Portuguese", "code": "pt"},
    {"flag": "🇷🇺", "name": "Russian", "code": "ru"},
    {"flag": "🇯🇵", "name": "Japanese", "code": "ja"},
    {"flag": "🇨🇳", "name": "Chinese", "code": "zh-CN"},
    {"flag": "🇰🇷", "name": "Korean", "code": "ko"},
    {"flag": "🇦🇪", "name": "Arabic", "code": "ar"},
    {"flag": "🇹🇷", "name": "Turkish", "code": "tr"},
    {"flag": "🇳🇱", "name": "Dutch", "code": "nl"},
    {"flag": "🇵🇱", "name": "Polish", "code": "pl"},
    {"flag": "🇸🇪", "name": "Swedish", "code": "sv"},
    {"flag": "🇳🇴", "name": "Norwegian", "code": "no"},
    {"flag": "🇩🇰", "name": "Danish", "code": "da"},
    {"flag": "🇫🇮", "name": "Finnish", "code": "fi"},
    {"flag": "🇬🇷", "name": "Greek", "code": "el"},
    {"flag": "🇮🇱", "name": "Hebrew", "code": "he"},
    {"flag": "🇹🇭", "name": "Thai", "code": "th"},
    {"flag": "🇻🇳", "name": "Vietnamese", "code": "vi"},
    {"flag": "🇮🇩", "name": "Indonesian", "code": "id"},
    {"flag": "🇲🇾", "name": "Malay", "code": "ms"},
    {"flag": "🇵🇭", "name": "Filipino", "code": "tl"},
    {"flag": "🇵🇰", "name": "Urdu", "code": "ur"},
    {"flag": "🇧🇩", "name": "Bengali", "code": "bn"},
    {"flag": "🇱🇰", "name": "Sinhala", "code": "si"},
    {"flag": "🇳🇵", "name": "Nepali", "code": "ne"},
    {"flag": "🇺🇦", "name": "Ukrainian", "code": "uk"},
    {"flag": "🇨🇿", "name": "Czech", "code": "cs"},
    {"flag": "🇭🇺", "name": "Hungarian", "code": "hu"},
    {"flag": "🇷🇴", "name": "Romanian", "code": "ro"},
    {"flag": "🇧🇬", "name": "Bulgarian", "code": "bg"},
    {"flag": "🇭🇷", "name": "Croatian", "code": "hr"},
    {"flag": "🇸🇰", "name": "Slovak", "code": "sk"},
    {"flag": "🇸🇮", "name": "Slovenian", "code": "sl"},
    {"flag": "🇱🇹", "name": "Lithuanian", "code": "lt"},
    {"flag": "🇱🇻", "name": "Latvian", "code": "lv"},
    {"flag": "🇪🇪", "name": "Estonian", "code": "et"},
    {"flag": "🇮🇸", "name": "Icelandic", "code": "is"},
    {"flag": "🇲🇹", "name": "Maltese", "code": "mt"},
    {"flag": "🇦🇱", "name": "Albanian", "code": "sq"},
    {"flag": "🇲🇰", "name": "Macedonian", "code": "mk"},
    {"flag": "🇧🇾", "name": "Belarusian", "code": "be"},
    {"flag": "🇬🇪", "name": "Georgian", "code": "ka"},
    {"flag": "🇦🇲", "name": "Armenian", "code": "hy"},
    {"flag": "🇦🇿", "name": "Azerbaijani", "code": "az"},
    {"flag": "🇰🇿", "name": "Kazakh", "code": "kk"},
    {"flag": "🇺🇿", "name": "Uzbek", "code": "uz"},
]

COUNTRIES_PER_PAGE = 15

def get_country_items():
    return COUNTRIES

def get_country_by_code(code):
    for country in COUNTRIES:
        if country["code"] == code:
            return country
    return None

def search_country(query):
    results = []
    query = query.lower()
    for country in COUNTRIES:
        if query in country["name"].lower() or query in country["code"].lower():
            results.append(country)
    return results
