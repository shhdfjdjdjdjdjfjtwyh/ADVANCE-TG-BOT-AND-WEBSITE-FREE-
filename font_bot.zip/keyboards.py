from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from fonts import FONT_STYLES, get_font_items, FONTS_PER_PAGE
from languages import COUNTRIES, COUNTRIES_PER_PAGE

# Button styles with emojis
FONT_BUTTON_STYLES = {
    "BNDEV": "🔵",
    "Serif": "📜",
    "SMALL CAPS": "🔠",
    "tiny": "🔡",
    "Sans": "⚪",
    "COROLEE": "✨",
    "Bothic": "🖤",
    "SQUARE": "⬜",
    "SPECTRUM": "🌈",
    "Frozen": "❄️",
    "Script": "✍️",
    "Comic": "🦸",
    "Bold": "💪",
    "Italic": "📎",
    "Monospace": "⌨️",
    "Cursive": "🖋️",
    "Upside": "🔄",
    "Mirror": "🪞",
    "Double": "🔢",
    "Strike": "✖️",
    "Underline": "📏",
    "Wide": "↔️",
    "Math Bold": "🔣",
    "Math Italic": "📐",
    "Circle": "⭕",
    "Parenthesis": "🔘",
}

def get_font_keyboard(page=0):
    """Build font keyboard - ALL GREEN buttons, navigation RED, Main Menu BLUE"""
    keyboard = []
    row = []
    font_items = get_font_items()
    total_fonts = len(font_items)
    total_pages = (total_fonts + FONTS_PER_PAGE - 1) // FONTS_PER_PAGE
    
    start = page * FONTS_PER_PAGE
    end = min(start + FONTS_PER_PAGE, total_fonts)
    
    for display_name, style_name in font_items[start:end]:
        emoji = FONT_BUTTON_STYLES.get(display_name, "🎨")
        button_text = f"{emoji} {display_name}"
        # GREEN buttons for all font options
        row.append(InlineKeyboardButton(button_text, callback_data=f"font_{style_name}", style="success"))
        if len(row) == 3:
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    # Navigation row with RED buttons
    nav_row = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("⬅️ BACK", callback_data=f"font_page_{page-1}", style="danger"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton("NEXT ➡️", callback_data=f"font_page_{page+1}", style="danger"))
    
    if nav_row:
        keyboard.append(nav_row)
    
    # Main Menu button - BLUE
    keyboard.append([InlineKeyboardButton("🏠 MAIN MENU", callback_data="menu_main", style="primary")])
    
    return InlineKeyboardMarkup(keyboard)

def get_language_keyboard(page=0):
    """Build language keyboard - 3 columns, ALL GREEN buttons, navigation RED, Main Menu BLUE"""
    keyboard = []
    row = []
    total_countries = len(COUNTRIES)
    total_pages = (total_countries + COUNTRIES_PER_PAGE - 1) // COUNTRIES_PER_PAGE
    
    start = page * COUNTRIES_PER_PAGE
    end = min(start + COUNTRIES_PER_PAGE, total_countries)
    
    for country in COUNTRIES[start:end]:
        display = f"{country['flag']} {country['name']}"
        # GREEN buttons for all language options - 3 columns
        row.append(InlineKeyboardButton(display, callback_data=f"lang_{country['code']}", style="success"))
        if len(row) == 3:  # Changed from 2 to 3
            keyboard.append(row)
            row = []
    if row:
        keyboard.append(row)
    
    # Navigation row with RED buttons
    nav_row = []
    if page > 0:
        nav_row.append(InlineKeyboardButton("⬅️ BACK", callback_data=f"lang_page_{page-1}", style="danger"))
    if page < total_pages - 1:
        nav_row.append(InlineKeyboardButton("NEXT ➡️", callback_data=f"lang_page_{page+1}", style="danger"))
    
    if nav_row:
        keyboard.append(nav_row)
    
    # Main Menu button - BLUE
    keyboard.append([InlineKeyboardButton("🏠 MAIN MENU", callback_data="menu_main", style="primary")])
    
    return InlineKeyboardMarkup(keyboard)

def get_main_keyboard():
    """Main menu keyboard - GREEN buttons only"""
    keyboard = [
        [
            InlineKeyboardButton("🎨 FRONTTXT", callback_data="menu_font", style="success"),
            InlineKeyboardButton("🌍 LANGUAGE", callback_data="menu_language", style="success"),
            InlineKeyboardButton("👨‍💻 DEVELOPER", callback_data="menu_developer", style="success")
        ]
    ]
    return InlineKeyboardMarkup(keyboard)
