# Bot Configuration ya ha ok bro
BOT_TOKEN = ""
BOT_NAME = "BNDEV"
DEVELOPER = "@BLOODYNIGHTMODMENU"
