# All Font Styles ya ha pl

FONT_STYLES = {
    "BNDEV": "bndev",
    "Serif": "serif",
    "SMALL CAPS": "smallcaps",
    "tiny": "tiny",
    "Sans": "sans",
    "COROLEE": "corolee",
    "Bothic": "gothic",
    "SQUARE": "square",
    "SPECTRUM": "spectrum",
    "Frozen": "frozen",
    "Script": "script",
    "Comic": "comic",
    "Bold": "bold",
    "Italic": "italic",
    "Monospace": "monospace",
    "Cursive": "cursive",
    "Upside": "upside",
    "Mirror": "mirror",
    "Double": "double",
    "Strike": "strike",
    "Underline": "underline",
    "Wide": "wide",
    "Math Bold": "mathbold",
    "Math Italic": "mathitalic",
    "Circle": "circle",
    "Parenthesis": "parenthesis",
}

FONTS_PER_PAGE = 15

def transform_text(text: str, style: str) -> str:
    """Transform text based on font style"""
    style = style.lower()
    
    # BNDEV - Special font
    if style == "bndev":
        mapping = {
            'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ',
            'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ',
            'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ', 's': 's', 't': 'ᴛ', 'u': 'ᴜ',
            'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ',
            'A': 'ᴀ', 'B': 'ʙ', 'C': 'ᴄ', 'D': 'ᴅ', 'E': 'ᴇ', 'F': 'ꜰ', 'G': 'ɢ',
            'H': 'ʜ', 'I': 'ɪ', 'J': 'ᴊ', 'K': 'ᴋ', 'L': 'ʟ', 'M': 'ᴍ', 'N': 'ɴ',
            'O': 'ᴏ', 'P': 'ᴘ', 'Q': 'ǫ', 'R': 'ʀ', 'S': 's', 'T': 'ᴛ', 'U': 'ᴜ',
            'V': 'ᴠ', 'W': 'ᴡ', 'X': 'x', 'Y': 'ʏ', 'Z': 'ᴢ'
        }
        return ''.join(mapping.get(c, c) for c in text)
    
    elif style == "serif":
        mapping = {
            'A': '𝐴', 'B': '𝐵', 'C': '𝐶', 'D': '𝐷', 'E': '𝐸', 'F': '𝐹', 'G': '𝐺',
            'H': '𝐻', 'I': '𝐼', 'J': '𝐽', 'K': '𝐾', 'L': '𝐿', 'M': '𝑀', 'N': '𝑁',
            'O': '𝑂', 'P': '𝑃', 'Q': '𝑄', 'R': '𝑅', 'S': '𝑆', 'T': '𝑇', 'U': '𝑈',
            'V': '𝑉', 'W': '𝑊', 'X': '𝑋', 'Y': '𝑌', 'Z': '𝑍',
            'a': '𝑎', 'b': '𝑏', 'c': '𝑐', 'd': '𝑑', 'e': '𝑒', 'f': '𝑓', 'g': '𝑔',
            'h': 'ℎ', 'i': '𝑖', 'j': '𝑗', 'k': '𝑘', 'l': '𝑙', 'm': '𝑚', 'n': '𝑛',
            'o': '𝑜', 'p': '𝑝', 'q': '𝑞', 'r': '𝑟', 's': '𝑠', 't': '𝑡', 'u': '𝑢',
            'v': '𝑣', 'w': '𝑤', 'x': '𝑥', 'y': '𝑦', 'z': '𝑧'
        }
        return ''.join(mapping.get(c, c) for c in text)
    
    elif style == "smallcaps":
        mapping = {
            'a': 'ᴀ', 'b': 'ʙ', 'c': 'ᴄ', 'd': 'ᴅ', 'e': 'ᴇ', 'f': 'ꜰ', 'g': 'ɢ',
            'h': 'ʜ', 'i': 'ɪ', 'j': 'ᴊ', 'k': 'ᴋ', 'l': 'ʟ', 'm': 'ᴍ', 'n': 'ɴ',
            'o': 'ᴏ', 'p': 'ᴘ', 'q': 'ǫ', 'r': 'ʀ', 's': 's', 't': 'ᴛ', 'u': 'ᴜ',
            'v': 'ᴠ', 'w': 'ᴡ', 'x': 'x', 'y': 'ʏ', 'z': 'ᴢ'
        }
        return ''.join(mapping.get(c, c) for c in text.upper())
    
    elif style == "tiny":
        mapping = {
            'a': 'ₐ', 'b': 'ᵦ', 'c': '꜀', 'd': 'ᵈ', 'e': 'ₑ', 'f': 'ᶠ', 'g': 'ᵍ',
            'h': 'ₕ', 'i': 'ᵢ', 'j': 'ⱼ', 'k': 'ₖ', 'l': 'ₗ', 'm': 'ₘ', 'n': 'ₙ',
            'o': 'ₒ', 'p': 'ₚ', 'q': 'q', 'r': 'ᵣ', 's': 'ₛ', 't': 'ₜ', 'u': 'ᵤ',
            'v': 'ᵥ', 'w': 'w', 'x': 'ₓ', 'y': 'y', 'z': 'z',
            'A': 'ᴬ', 'B': 'ᴮ', 'C': 'ᶜ', 'D': 'ᴰ', 'E': 'ᴱ', 'F': 'ᶠ', 'G': 'ᴳ',
            'H': 'ᴴ', 'I': 'ᴵ', 'J': 'ᴶ', 'K': 'ᴷ', 'L': 'ᴸ', 'M': 'ᴹ', 'N': 'ᴺ',
            'O': 'ᴼ', 'P': 'ᴾ', 'Q': 'Q', 'R': 'ᴿ', 'S': 'ˢ', 'T': 'ᵀ', 'U': 'ᵁ',
            'V': 'ⱽ', 'W': 'ᵂ', 'X': 'ˣ', 'Y': 'ʸ', 'Z': 'ᶻ'
        }
        return ''.join(mapping.get(c, c) for c in text)
    
    elif style == "sans":
        mapping = {
            'A': '𝖠', 'B': '𝖡', 'C': '𝖢', 'D': '𝖣', 'E': '𝖤', 'F': '𝖥', 'G': '𝖦',
            'H': '𝖧', 'I': '𝖨', 'J': '𝖩', 'K': '𝖪', 'L': '𝖫', 'M': '𝖬', 'N': '𝖭',
            'O': '𝖮', 'P': '𝖯', 'Q': '𝖰', 'R': '𝖱', 'S': '𝖲', 'T': '𝖳', 'U': '𝖴',
            'V': '𝖵', 'W': '𝖶', 'X': '𝖷', 'Y': '𝖸', 'Z': '𝖹',
            'a': '𝖺', 'b': '𝖻', 'c': '𝖼', 'd': '𝖽', 'e': '𝖾', 'f': '𝖿', 'g': '𝗀',
            'h': '𝗁', 'i': '𝗂', 'j': '𝗃', 'k': '𝗄', 'l': '𝗅', 'm': '𝗆', 'n': '𝗇',
            'o': '𝗈', 'p': '𝗉', 'q': '𝗊', 'r': '𝗋', 's': '𝗌', 't': '𝗍', 'u': '𝗎',
            'v': '𝗏', 'w': '𝗐', 'x': '𝗑', 'y': '𝗒', 'z': '𝗓'
        }
        return ''.join(mapping.get(c, c) for c in text)
    
    elif style == "bold":
        return ''.join(chr(0x1D400 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D41A + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "italic":
        return ''.join(chr(0x1D434 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D44E + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "monospace":
        return ''.join(chr(0x1D670 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D68A + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "upside":
        upside_map = {
            'a': 'ɐ', 'b': 'q', 'c': 'ɔ', 'd': 'p', 'e': 'ǝ', 'f': 'ɟ', 'g': 'ƃ',
            'h': 'ɥ', 'i': 'ᴉ', 'j': 'ɾ', 'k': 'ʞ', 'l': 'ן', 'm': 'ɯ', 'n': 'u',
            'o': 'o', 'p': 'd', 'q': 'b', 'r': 'ɹ', 's': 's', 't': 'ʇ', 'u': 'n',
            'v': 'ʌ', 'w': 'ʍ', 'x': 'x', 'y': 'ʎ', 'z': 'z',
            'A': '∀', 'B': '𐌁', 'C': 'Ɔ', 'D': '◖', 'E': 'Ǝ', 'F': 'Ⅎ', 'G': '⅁',
            'H': 'H', 'I': 'I', 'J': 'ſ', 'K': 'ʞ', 'L': '˥', 'M': 'W', 'N': 'N',
            'O': 'O', 'P': 'Ԁ', 'Q': 'Q', 'R': 'ᴚ', 'S': 'S', 'T': '⊥', 'U': '∩',
            'V': 'Λ', 'W': 'M', 'X': 'X', 'Y': '⅄', 'Z': 'Z'
        }
        return ''.join(upside_map.get(c, c) for c in text[::-1])
    
    elif style == "mirror":
        return text[::-1]
    
    elif style == "double":
        return ''.join(chr(0x1D538 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D552 + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "strike":
        return ''.join(c + '\u0336' for c in text)
    
    elif style == "underline":
        return ''.join(c + '\u0332' for c in text)
    
    elif style == "wide":
        return ''.join(chr(0xFF21 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0xFF41 + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "mathbold":
        return ''.join(chr(0x1D5A0 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D5BA + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "mathitalic":
        return ''.join(chr(0x1D5D4 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D5EE + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "circle":
        circle_map = {
            'a': 'ⓐ', 'b': 'ⓑ', 'c': 'ⓒ', 'd': 'ⓓ', 'e': 'ⓔ', 'f': 'ⓕ', 'g': 'ⓖ',
            'h': 'ⓗ', 'i': 'ⓘ', 'j': 'ⓙ', 'k': 'ⓚ', 'l': 'ⓛ', 'm': 'ⓜ', 'n': 'ⓝ',
            'o': 'ⓞ', 'p': 'ⓟ', 'q': 'ⓠ', 'r': 'ⓡ', 's': 'ⓢ', 't': 'ⓣ', 'u': 'ⓤ',
            'v': 'ⓥ', 'w': 'ⓦ', 'x': 'ⓧ', 'y': 'ⓨ', 'z': 'ⓩ',
            'A': 'Ⓐ', 'B': 'Ⓑ', 'C': 'Ⓒ', 'D': 'Ⓓ', 'E': 'Ⓔ', 'F': 'Ⓕ', 'G': 'Ⓖ',
            'H': 'Ⓗ', 'I': 'Ⓘ', 'J': 'Ⓙ', 'K': 'Ⓚ', 'L': 'Ⓛ', 'M': 'Ⓜ', 'N': 'Ⓝ',
            'O': 'Ⓞ', 'P': 'Ⓟ', 'Q': 'Ⓠ', 'R': 'Ⓡ', 'S': 'Ⓢ', 'T': 'Ⓣ', 'U': 'Ⓤ',
            'V': 'Ⓥ', 'W': 'Ⓦ', 'X': 'Ⓧ', 'Y': 'Ⓨ', 'Z': 'Ⓩ'
        }
        return ''.join(circle_map.get(c, c) for c in text)
    
    elif style == "parenthesis":
        paren_map = {
            'a': '⒜', 'b': '⒝', 'c': '⒞', 'd': '⒟', 'e': '⒠', 'f': '⒡', 'g': '⒢',
            'h': '⒣', 'i': '⒤', 'j': '⒥', 'k': '⒦', 'l': '⒧', 'm': '⒨', 'n': '⒩',
            'o': '⒪', 'p': '⒫', 'q': '⒬', 'r': '⒭', 's': '⒮', 't': '⒯', 'u': '⒰',
            'v': '⒱', 'w': '⒲', 'x': '⒳', 'y': '⒴', 'z': '⒵',
            'A': '⒜', 'B': '⒝', 'C': '⒞', 'D': '⒟', 'E': '⒠', 'F': '⒡', 'G': '⒢',
            'H': '⒣', 'I': '⒤', 'J': '⒥', 'K': '⒦', 'L': '⒧', 'M': '⒨', 'N': '⒩',
            'O': '⒪', 'P': '⒫', 'Q': '⒬', 'R': '⒭', 'S': '⒮', 'T': '⒯', 'U': '⒰',
            'V': '⒱', 'W': '⒲', 'X': '⒳', 'Y': '⒴', 'Z': '⒵'
        }
        return ''.join(paren_map.get(c, c) for c in text)
    
    elif style == "corolee":
        return f"✨ {text} ✨"
    
    elif style == "gothic":
        return ''.join(chr(0x1D504 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D51E + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "square":
        return f"🟦 {text} 🟦"
    
    elif style == "spectrum":
        return f"🌈 {text} 🌈"
    
    elif style == "frozen":
        return f"❄️ {text} ❄️"
    
    elif style == "script":
        return ''.join(chr(0x1D4B0 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D4CA + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    elif style == "comic":
        return f"🦸 {text} 🦸"
    
    elif style == "cursive":
        return ''.join(chr(0x1D4D0 + ord(c) - 0x41) if 'A' <= c <= 'Z' else 
                       chr(0x1D4EA + ord(c) - 0x61) if 'a' <= c <= 'z' else c for c in text)
    
    return text

def get_font_items():
    return list(FONT_STYLES.items())

def get_total_fonts():
    return len(FONT_STYLES)
