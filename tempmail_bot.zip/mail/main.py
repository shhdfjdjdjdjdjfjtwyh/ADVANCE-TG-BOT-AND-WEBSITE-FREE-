#!/usr/bin/env python3
#BOT DEVLOPER - @BLOODYNIGHTMODMENU BOT CODE NOT FOR SELL ONLY OWN USE
import requests
import time
import re
import threading
import sys

BOT_TOKEN = "your bot token ok"
TG = f"https://api.telegram.org/bot{BOT_TOKEN}"
GM = "https://api.guerrillamail.com/ajax.php"
DEVELOPER_URL = "https://t.me/BLOODYNIGHTMODMENU"

sessions = {}
offset = 0

SKIP_KEYWORDS = [
    "welcome to guerrillamail",
    "welcome to guerrilla mail",
    "guerrillamail welcome",
    "welcome mail",
]

def gm_new():
    try:
        r = requests.get(GM, params={"f": "get_email_address", "lang": "en"}, timeout=10)
        return r.json()
    except Exception as e:
        print("GM new err:", e)
        return {}


def is_skippable(mail):
  
    sub = (mail.get("mail_subject") or "").lower()
    frm = (mail.get("mail_from") or "").lower()
    
   
    for kw in SKIP_KEYWORDS:
        if kw in sub:
            return True
    
    
    if "guerrillamail" in frm and "welcome" in sub:
        return True
    
    return False


def gm_check(sid, seq=0):
    try:
        r = requests.get(GM, params={
            "f": "check_email", "seq": seq, "sid_token": sid,
            "_": int(time.time() * 1000)
        }, timeout=10)
        mails = r.json().get("list", [])
        
        
        filtered = [m for m in mails if not is_skippable(m)]
        return filtered
    except Exception as e:
        print("GM check err:", e)
        return []


def gm_fetch(sid, mail_id):
    try:
        r = requests.get(GM, params={
            "f": "fetch_email", "email_id": mail_id, "sid_token": sid
        }, timeout=10)
        return r.json()
    except Exception as e:
        print("GM fetch err:", e)
        return {}


def tg(method, **params):
    try:
        r = requests.post(f"{TG}/{method}", json=params, timeout=20)
        return r.json()
    except Exception as e:
        print("TG err:", e)
        return {"ok": False, "description": str(e)}


def safe_call(method, **params):
    res = tg(method, **params)
    if not res.get("ok"):
        desc = (res.get("description") or "").lower()
        if "style" in desc or "unknown" in desc or "invalid" in desc:
            rm = params.get("reply_markup")
            if rm and "inline_keyboard" in rm:
                for row in rm["inline_keyboard"]:
                    for bt in row:
                        bt.pop("style", None)
                res = tg(method, **params)
    return res


def send(chat_id, text, kb=None):
    p = {"chat_id": chat_id, "text": text, "parse_mode": "HTML",
         "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return safe_call("sendMessage", **p)


def edit(chat_id, msg_id, text, kb=None):
    p = {"chat_id": chat_id, "message_id": msg_id, "text": text,
         "parse_mode": "HTML", "disable_web_page_preview": True}
    if kb:
        p["reply_markup"] = {"inline_keyboard": kb}
    return safe_call("editMessageText", **p)


def answer_cb(cb_id, text=None, alert=False):
    p = {"callback_query_id": cb_id}
    if text:
        p["text"] = text
    if alert:
        p["show_alert"] = True
    tg("answerCallbackQuery", **p)


def b(text, data, style=None):
    x = {"text": text, "callback_data": data}
    if style:
        x["style"] = style
    return x


def b_url(text, url, style=None):
    x = {"text": text, "url": url}
    if style:
        x["style"] = style
    return x


def kb_main(has_email):
    if has_email:
        return [
            [b("📧 New Email", "new", "success"),
             b("📬 Inbox", "inbox", "success")],
            [b("📋 Copy Email", "copy", "success"),
             b("⏱️ Auto-Refresh", "auto", "primary")],
            [b("🗑️ Delete", "delete", "danger")],
            [b_url("👨‍💻 DEVELOPER", DEVELOPER_URL, "primary")],
        ]
    return [
        [b("📧 Generate New Email", "new", "success")],
        [b_url("👨‍💻 DEVELOPER", DEVELOPER_URL, "primary")],
    ]


def kb_back(extra=None):
    rows = []
    if extra:
        rows.extend(extra)
    rows.append([b("🔙 Back", "back", "danger")])
    return rows


def main_text(sess):
    if sess.get("email"):
        return (f"📧 <b>TempMail Bot dev - @BLOODYNIGHTMODMENU</b>\n\n"
                f"<b>Active Email:</b>\n<code>{sess['email']}</code>\n\n"
                f"<i>Tap email to copy • Use buttons below</i>")
    return ("📧 <b>Welcome to TempMail Bot!</b>\n\n"
            "bndevlopers @BLOODYNIGHTMODMENU Generate a disposable email address to start receiving mail.\n"
            "🔒 No registration • Auto-deletes")



def show_main(chat_id, msg_id=None):
    sess = sessions.get(chat_id, {})
    text = main_text(sess)
    kb = kb_main(bool(sess.get("email")))
    if msg_id:
        edit(chat_id, msg_id, text, kb)
    else:
        send(chat_id, text, kb)


def do_new_email(chat_id, msg_id, cb_id):
    if cb_id:
        answer_cb(cb_id)
    info = gm_new()
    sid = info.get("sid_token")
    email = info.get("email_addr")
    if not email:
        edit(chat_id, msg_id, "❌ <b>Failed to generate email.</b> Try again.",
             kb_main(False))
        return
    sessions[chat_id] = {"sid": sid, "email": email, "mails": [], "auto": False}
    text = (f"✅ <b>New Email Generated!</b>\n\n"
            f"📧 <code>{email}</code>\n\n"
            f"<i>Tap the email to copy it</i>")
    edit(chat_id, msg_id, text, kb_main(True))


def do_refresh(chat_id, msg_id, cb_id):
    sess = sessions.get(chat_id)
    if not sess or not sess.get("email"):
        if cb_id:
            answer_cb(cb_id, "⚠️ Generate an email first!", True)
        return
    
    if cb_id:
        answer_cb(cb_id, "🔄 Refreshing mail...")
    
    new_mails = gm_check(sess["sid"])
    
    
    existing_ids = {m["mail_id"] for m in sess.get("mails", [])}
    for m in new_mails:
        if m["mail_id"] not in existing_ids:
           
            if not is_skippable(m):
                sess["mails"].append(m)
    
    # Remove any skippable mails from existing cache
    sess["mails"] = [m for m in sess.get("mails", []) if not is_skippable(m)]
    
    all_mails = sess.get("mails", [])
    
    if not all_mails:
        edit(chat_id, msg_id,
             f"📭 <b>Inbox is empty</b>\n\n<code>{sess['email']}</code>\n\n"
             f"<i>Waiting for new mail...</i>",
             kb_back([[b("🔄 Refresh", "inbox", "success")]]))
        return

    rows = []
    for i, m in enumerate(all_mails[:10], 1):
        sub = (m.get("mail_subject") or "(no subject)")[:35]
        rows.append([b(f"{i}. {sub}", f"read:{m['mail_id']}", "success")])
    
    rows.append([b("🔄 Refresh", "inbox", "success")])

    text = (f"📬 <b>Inbox ({len(all_mails)} mail"
            f"{'s' if len(all_mails) > 1 else ''})</b>\n\n"
            f"<code>{sess['email']}</code>")
    
    edit(chat_id, msg_id, text, kb_back(rows))


def do_read(chat_id, msg_id, cb_id, mail_id):
    sess = sessions.get(chat_id)
    if not sess:
        answer_cb(cb_id, "Session expired", True)
        return
    answer_cb(cb_id)

    m = gm_fetch(sess["sid"], mail_id)
    body = m.get("mail_body", "") or ""
    clean = re.sub(r"<[^>]+>", "", body)
    for a, bch in [("&nbsp;", " "), ("&amp;", "&"),
                   ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"')]:
        clean = clean.replace(a, bch)
    clean = clean.strip()[:3500]

    sub = (m.get("mail_subject") or "(no subject)")[:80]
    frm = m.get("mail_from", "unknown")

    text = (f"📩 <b>{sub}</b>\n\n"
            f"👤 From: <code>{frm}</code>\n\n"
            f"───────────────\n{clean or '(empty body)'}")
    edit(chat_id, msg_id, text,
         kb_back([[b("📬 Back to Inbox", "inbox", "success")]]))


def do_copy(chat_id, cb_id):
    sess = sessions.get(chat_id)
    if not sess or not sess.get("email"):
        answer_cb(cb_id, "⚠️ No email yet!", True)
        return
    answer_cb(cb_id, "📋 Sent below!")
    send(chat_id,
         f"📋 <b>Your Email Address</b>\n\n"
         f"<code>{sess['email']}</code>\n\n"
         f"<i>Tap on it to copy</i>")


def do_delete(chat_id, msg_id, cb_id):
    sessions.pop(chat_id, None)
    answer_cb(cb_id, "🗑️ Deleted")
    edit(chat_id, msg_id,
         "🗑️ <b>Session Deleted</b>\n\nGenerate a new email to start again.",
         kb_main(False))


def do_auto(chat_id, msg_id, cb_id):
    sess = sessions.get(chat_id)
    if not sess or not sess.get("email"):
        answer_cb(cb_id, "⚠️ Generate email first!", True)
        return
    sess["auto"] = True
    answer_cb(cb_id, "⏱️ Auto-refresh ON (60s)")
    edit(chat_id, msg_id,
         f"⏱️ <b>Auto-Refresh Running</b>\n\n"
         f"Checking every 5 seconds for 60 seconds...\n\n"
         f"<code>{sess['email']}</code>",
         kb_back([[b("⏹️ Stop", "auto_stop", "danger")]]))

    def watcher():
        for _ in range(12):
            time.sleep(5)
            s = sessions.get(chat_id)
            if not s or not s.get("auto"):
                return
            mails = gm_check(s["sid"])
            if mails:
                existing_ids = {m["mail_id"] for m in s.get("mails", [])}
                new_count = 0
                for m in mails:
                    if m["mail_id"] not in existing_ids and not is_skippable(m):
                        s["mails"].append(m)
                        new_count += 1
                
                if new_count > 0:
                    s["auto"] = False
                    send(chat_id,
                         f"🔔 <b>{new_count} new email"
                         f"{'s' if new_count>1 else ''} received!</b>\n\n"
                         f"Tap below to view.",
                         [[b("📬 Open Inbox", "inbox", "success")]])
                    return
        s = sessions.get(chat_id)
        if s:
            s["auto"] = False
        send(chat_id, "⏹️ Auto-refresh stopped.")

    threading.Thread(target=watcher, daemon=True).start()



def handle_callback(cb):
    try:
        chat_id = cb["message"]["chat"]["id"]
        msg_id = cb["message"]["message_id"]
        data = cb["data"]
        cb_id = cb["id"]
    except (KeyError, TypeError):
        return

    if data == "back":
        show_main(chat_id, msg_id)
        answer_cb(cb_id)
        return

    if data == "new":
        do_new_email(chat_id, msg_id, cb_id)
        return

    if data in ("refresh", "inbox"):
        do_refresh(chat_id, msg_id, cb_id)
        return

    if data.startswith("read:"):
        do_read(chat_id, msg_id, cb_id, data.split(":", 1)[1])
        return

    if data == "copy":
        do_copy(chat_id, cb_id)
        return

    if data == "delete":
        do_delete(chat_id, msg_id, cb_id)
        return

    if data == "auto":
        do_auto(chat_id, msg_id, cb_id)
        return

    if data == "auto_stop":
        s = sessions.get(chat_id)
        if s:
            s["auto"] = False
        answer_cb(cb_id, "Stopped")
        show_main(chat_id, msg_id)
        return

    answer_cb(cb_id)


def main():
    global offset
    print("🤖 Bot starting...")
    me = tg("getMe")
    if not me.get("ok"):
        print("❌ Invalid BOT_TOKEN:", me)
        sys.exit(1)
    print(f"✅ Logged in as @{me['result']['username']}")

    r = tg("getUpdates", offset=-1, timeout=0)
    if r.get("ok") and r["result"]:
        offset = r["result"][-1]["update_id"] + 1

    while True:
        try:
            r = tg("getUpdates", offset=offset, timeout=25)
            if not r.get("ok"):
                time.sleep(2)
                continue
            for upd in r["result"]:
                offset = upd["update_id"] + 1

                if "message" in upd:
                    msg = upd["message"]
                    chat_id = msg["chat"]["id"]
                    text = msg.get("text", "")
                    if text.startswith("/start") or text.startswith("/menu"):
                        sess = sessions.get(chat_id, {})
                        send(chat_id, main_text(sess),
                             kb_main(bool(sess.get("email"))))
                    elif text.startswith("/new"):
                        sent = send(chat_id, "⏳ Generating...")
                        if sent.get("ok"):
                            do_new_email(chat_id,
                                         sent["result"]["message_id"],
                                         None)
                    elif text.startswith("/inbox"):
                        sent = send(chat_id, "⏳ Loading inbox...")
                        if sent.get("ok"):
                            do_refresh(chat_id,
                                       sent["result"]["message_id"],
                                       None)
                    else:
                        send(chat_id, "Use /start to open menu.")

                elif "callback_query" in upd:
                    handle_callback(upd["callback_query"])

        except KeyboardInterrupt:
            print("\n bnbot stop ok  bot...")
            break
        except Exception as e:
            print("Loop err:", e)
            time.sleep(2)


if __name__ == "__main__":
    main()
#BOT DEVLOPER - @BLOODYNIGHTMODMENU BOT CODE NOT FOR SELL ONLY OWN USE