from telethon import TelegramClient
from config import API_ID, API_HASH, BOT_TOKEN
from handlers import register_all

bot = TelegramClient("otp_reader_bot", API_ID, API_HASH)
bot.start(bot_token=BOT_TOKEN)

register_all(bot)

print("bndev (multi-user safe)")
bot.run_until_disconnected()
