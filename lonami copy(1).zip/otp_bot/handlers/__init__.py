#bndevloper copy bot for free for own project use and enjoy dont sell
from . import start, create_session, read_otp

def register_all(bot):
    start.register(bot)
    create_session.register(bot)
    read_otp.register(bot)
    read_otp.register_otp_button(bot)
#bndevloper copy bot for free for own project use and enjoy dont sell