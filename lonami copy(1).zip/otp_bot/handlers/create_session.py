#bndevloper copy bot for free for own project use and enjoy dont sell
import re
from telethon import events
from telethon import TelegramClient
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError

from config import API_ID, API_HASH
from utils.state import user_state
from utils.helpers import build_session_zip
from handlers.start import (
    MAIN_KB_EXPORT as MAIN_KB,
    CANCEL_KB_EXPORT as CANCEL_KB,
    BTN_CREATE_EXPORT as BTN_CREATE,
    BTN_READ_EXPORT as BTN_READ,
    BTN_CANCEL_EXPORT as BTN_CANCEL,
)


def register(bot):

    @bot.on(events.NewMessage(func=lambda e: e.is_private and e.text == BTN_CREATE))
    async def _create(e):
        uid = e.sender_id
        user_state.clear(uid)
        user_state.set(uid, step="waiting_phone")
        await e.reply(
            "📞 **Input your number** Ex: +62850000000",
            buttons=CANCEL_KB,
            parse_mode="md"
        )

    @bot.on(events.NewMessage(func=lambda e: e.is_private and e.text))
    async def _text(e):
        uid = e.sender_id
        st = user_state.get(uid)
        step = st.get("step")
        if not step:
            return
        if e.text in (BTN_CREATE, BTN_READ, BTN_CANCEL):
            return

        lock = user_state.lock(uid)
        async with lock:
            await handle_step(e, uid, step)


async def handle_step(e, uid, step):
    st = user_state.get(uid)

    if step == "waiting_phone":
        phone = e.text.strip()
        if not re.match(r"^\+\d{8,15}$", phone):
            await e.reply("❌ Invalid. Ex: +62850000000")
            return

        await e.reply("♻️ Processing...")

        client = TelegramClient(StringSession(), API_ID, API_HASH)
        await client.connect()
        try:
            sent = await client.send_code_request(phone)
        except Exception as ex:
            await e.reply(f"❌ Error: {ex}")
            await client.disconnect()
            return

        user_state.set(
            uid,
            step="waiting_otp",
            phone=phone,
            client=client,
            phone_code_hash=sent.phone_code_hash
        )
        await e.reply("🧩 **Input OTP Code:**", parse_mode="md")
        return

    if step == "waiting_otp":
        otp = e.text.strip().replace(" ", "")
        client = st["client"]
        phone = st["phone"]
        try:
            await client.sign_in(phone=phone, code=otp,
                                 phone_code_hash=st["phone_code_hash"])
        except SessionPasswordNeededError:
            user_state.set(uid, step="waiting_2fa")
            await e.reply("🔐 **Input 2FA Password:**", parse_mode="md")
            return
        except PhoneCodeInvalidError:
            await e.reply("❌ Invalid OTP. फिर भेजें:")
            return
        except Exception as ex:
            await e.reply(f"❌ Error: {ex}")
            return

        await _finish(e, uid)
        return

    if step == "waiting_2fa":
        pwd = e.text.strip()
        client = st["client"]
        try:
            await client.sign_in(password=pwd)
        except Exception as ex:
            await e.reply(f"❌ 2FA Error: {ex}")
            return
        await _finish(e, uid)
        return


async def _finish(e, uid):
    st = user_state.get(uid)
    client = st["client"]
    phone = st["phone"]

    me = await client.get_me()
    session_str = client.session.save()

    await client.disconnect()

    zip_path = await build_session_zip(phone, session_str)
    user_state.clear(uid)

    await e.reply(
        f"✅ **Session Created**\n\n"
        f"👤 User: {me.first_name or 'Unknown'}\n"
        f"📱 Number: {phone}\n\n"
        f"📦 आपका session ZIP:",
        file=zip_path,
        parse_mode="md",
        buttons=MAIN_KB
    )
#bndevloper copy bot for free for own project use and enjoy dont sell