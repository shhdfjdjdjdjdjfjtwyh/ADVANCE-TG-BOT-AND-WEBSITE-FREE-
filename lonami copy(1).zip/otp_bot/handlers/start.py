#bndevloper copy bot for free for own project use and enjoy dont sell
from telethon import events, Button

BTN_CREATE = "𝒄𝒓𝒆𝒂𝒕𝒆 𝒔𝒆𝒔𝒔𝒊𝒐𝒏"
BTN_READ   = "𝒓𝒆𝒂𝒅 𝑶𝑻𝑷"
BTN_CANCEL = "❌ Cancel"

#
MAIN_KB = [
    [
        Button.text(BTN_CREATE, resize=True, single_use=False),
        Button.text(BTN_READ, resize=True, single_use=False),
    ],
]

CANCEL_KB = [
    [Button.text(BTN_CANCEL, resize=True, single_use=False)],
]


def register(bot):

    @bot.on(events.NewMessage(pattern="/start"))
    async def _start(e):
        await e.reply(
            "🤖 **Welcome to OTP Reader Bot**\n\n👇  keyboard option :",
            buttons=MAIN_KB,
            parse_mode="md"
        )

    @bot.on(events.NewMessage(func=lambda e: e.is_private and e.text == BTN_CANCEL))
    async def _cancel(e):
        from utils.state import user_state
        uid = e.sender_id
        st = user_state.get(uid)
        cli = st.get("client")
        if cli:
            try: await cli.disconnect()
            except: pass
        user_state.clear(uid)
        await e.reply("❌ Cancelled.", buttons=MAIN_KB)


MAIN_KB_EXPORT = MAIN_KB
CANCEL_KB_EXPORT = CANCEL_KB
BTN_CREATE_EXPORT = BTN_CREATE
BTN_READ_EXPORT = BTN_READ
BTN_CANCEL_EXPORT = BTN_CANCEL
#bndevloper copy bot for free for own project use and enjoy dont sell