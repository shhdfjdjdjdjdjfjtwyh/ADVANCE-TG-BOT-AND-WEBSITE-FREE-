#bndevloper copy bot for free for own project use and enjoy dont sell
import os, re, zipfile, shutil
from telethon import TelegramClient
from config import SESSIONS_DIR


def extract_zip(zip_path: str, out_dir: str) -> list:
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir, ignore_errors=True)
    os.makedirs(out_dir, exist_ok=True)

    with zipfile.ZipFile(zip_path, "r") as z:
        z.extractall(out_dir)

    sessions = []
    for root, _, files in os.walk(out_dir):
        for f in files:
            if f.endswith(".session"):
                sessions.append(os.path.join(root, f))
    return sessions


async def get_latest_otp(client: TelegramClient):
    """
    """
    try:
      
        messages = await client.get_messages(777000, limit=10)

        for msg in messages:
            if not msg or not msg.text:
                continue

            text = msg.text

           
            m = re.search(r"(?:code|Code|CODE)[^\d]{0,10}(\d{4,6})", text)
            if m:
                return m.group(1)

        
        for msg in messages:
            if not msg or not msg.text:
                continue
            m = re.search(r"\b(\d{5})\b", msg.text)
            if m:
                return m.group(1)

    except Exception as e:
        print(f"[get_latest_otp] error: {e}")

    return None


async def build_session_zip(phone: str, session_string: str) -> str:
    phone_clean = phone.replace("+", "")
    sess_path = os.path.join(SESSIONS_DIR, f"{phone_clean}.session")
    zip_path = os.path.join(SESSIONS_DIR, f"{phone_clean}.zip")

    with open(sess_path, "w", encoding="utf-8") as f:
        f.write(session_string)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(sess_path, arcname=f"{phone_clean}.session")

    return zip_path
#bndevloper copy bot for free for own project use and enjoy dont sell