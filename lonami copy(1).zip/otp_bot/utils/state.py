#bndevloper copy bot for free for own project use and enjoy dont sell
import asyncio
from typing import Dict, Any

class UserState:
    def __init__(self):
        self._data: Dict[int, Dict[str, Any]] = {}
        self._locks: Dict[int, asyncio.Lock] = {}

    def get(self, user_id: int) -> Dict[str, Any]:
        return self._data.setdefault(user_id, {})

    def set(self, user_id: int, **kwargs):
        self._data.setdefault(user_id, {}).update(kwargs)

    def clear(self, user_id: int):
        self._data.pop(user_id, None)

    def lock(self, user_id: int) -> asyncio.Lock:
        if user_id not in self._locks:
            self._locks[user_id] = asyncio.Lock()
        return self._locks[user_id]


user_state = UserState()
pending_otp: Dict[str, dict] = {}
#bndevloper copy bot for free for own project use and enjoy dont sell