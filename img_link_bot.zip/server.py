# @BLOODYNIGHTMODMENU code not for sell use own use
import os
# @BLOODYNIGHTMODMENU code not for sell use own use
import threading
# @BLOODYNIGHTMODMENU code not for sell use own use
import subprocess
# @BLOODYNIGHTMODMENU code not for sell use own use
import re
# @BLOODYNIGHTMODMENU code not for sell use own use
import time
# @BLOODYNIGHTMODMENU code not for sell use own use
from flask import Flask, send_from_directory, jsonify
# @BLOODYNIGHTMODMENU code not for sell use own use
from flask_cors import CORS

# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# FLASK SERVER
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
app = Flask(__name__)
# @BLOODYNIGHTMODMENU code not for sell use own use
CORS(app)

# @BLOODYNIGHTMODMENU code not for sell use own use
UPLOAD_FOLDER = "uploads"
# @BLOODYNIGHTMODMENU code not for sell use own use
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# @BLOODYNIGHTMODMENU code not for sell use own use
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# @BLOODYNIGHTMODMENU code not for sell use own use
tunnel_url = {"url": ""}


# @BLOODYNIGHTMODMENU code not for sell use own use
@app.route('/')
# @BLOODYNIGHTMODMENU code not for sell use own use
def index():
# @BLOODYNIGHTMODMENU code not for sell use own use
    return "Image Link Server Running!"


# @BLOODYNIGHTMODMENU code not for sell use own use
@app.route('/img/<user_id>/<filename>')
# @BLOODYNIGHTMODMENU code not for sell use own use
def serve_image(user_id, filename):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Serve user's image"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        folder = os.path.join(UPLOAD_FOLDER, str(user_id))
# @BLOODYNIGHTMODMENU code not for sell use own use
        filepath = os.path.join(folder, filename)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        if os.path.exists(filepath):
# @BLOODYNIGHTMODMENU code not for sell use own use
            return send_from_directory(folder, filename)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return "Image not found", 404
# @BLOODYNIGHTMODMENU code not for sell use own use
    except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return str(e), 500


# @BLOODYNIGHTMODMENU code not for sell use own use
@app.route('/health')
# @BLOODYNIGHTMODMENU code not for sell use own use
def health():
# @BLOODYNIGHTMODMENU code not for sell use own use
    return jsonify({"status": "ok", "tunnel": tunnel_url["url"]})


# @BLOODYNIGHTMODMENU code not for sell use own use
def run_flask():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Run Flask in background"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# CLOUDFLARE TUNNEL
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def download_cloudflared():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Download cloudflared if not exists"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not os.path.exists("cloudflared/cloudflared"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        os.makedirs("cloudflared", exist_ok=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        print("📥 Downloading cloudflared...")
# @BLOODYNIGHTMODMENU code not for sell use own use
        os.system(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 "
# @BLOODYNIGHTMODMENU code not for sell use own use
            "-O cloudflared/cloudflared"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        os.system("chmod +x cloudflared/cloudflared")
# @BLOODYNIGHTMODMENU code not for sell use own use
        print("✅ Cloudflared downloaded!")


# @BLOODYNIGHTMODMENU code not for sell use own use
def start_tunnel():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Start Cloudflare Tunnel and get URL"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    download_cloudflared()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    def run():
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            process = subprocess.Popen(
# @BLOODYNIGHTMODMENU code not for sell use own use
                ["./cloudflared/cloudflared", "tunnel", "--url", "http://localhost:5000"],
# @BLOODYNIGHTMODMENU code not for sell use own use
                stdout=subprocess.PIPE,
# @BLOODYNIGHTMODMENU code not for sell use own use
                stderr=subprocess.STDOUT,
# @BLOODYNIGHTMODMENU code not for sell use own use
                text=True,
# @BLOODYNIGHTMODMENU code not for sell use own use
                bufsize=1
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
            
# @BLOODYNIGHTMODMENU code not for sell use own use
            for line in iter(process.stdout.readline, ''):
# @BLOODYNIGHTMODMENU code not for sell use own use
                print(line, end='')
# @BLOODYNIGHTMODMENU code not for sell use own use
                # Find tunnel URL
# @BLOODYNIGHTMODMENU code not for sell use own use
                match = re.search(r'https://[a-zA-Z0-9-]+\.trycloudflare\.com', line)
# @BLOODYNIGHTMODMENU code not for sell use own use
                if match:
# @BLOODYNIGHTMODMENU code not for sell use own use
                    url = match.group(0)
# @BLOODYNIGHTMODMENU code not for sell use own use
                    tunnel_url["url"] = url
# @BLOODYNIGHTMODMENU code not for sell use own use
                    print(f"\n✅ TUNNEL URL: {url}\n")
                    
# @BLOODYNIGHTMODMENU code not for sell use own use
                    # Save to database
# @BLOODYNIGHTMODMENU code not for sell use own use
                    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
                        from database import set_tunnel_url
# @BLOODYNIGHTMODMENU code not for sell use own use
                        set_tunnel_url(url)
# @BLOODYNIGHTMODMENU code not for sell use own use
                    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
                        pass
# @BLOODYNIGHTMODMENU code not for sell use own use
        except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
            print(f"❌ Tunnel error: {e}")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    thread = threading.Thread(target=run, daemon=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
    thread.start()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Wait for URL
# @BLOODYNIGHTMODMENU code not for sell use own use
    for _ in range(30):
# @BLOODYNIGHTMODMENU code not for sell use own use
        if tunnel_url["url"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
            break
# @BLOODYNIGHTMODMENU code not for sell use own use
        time.sleep(1)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return tunnel_url["url"]


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_url():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Get current tunnel URL"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return tunnel_url["url"]


# @BLOODYNIGHTMODMENU code not for sell use own use
def start_server():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Start Flask server in background"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    flask_thread = threading.Thread(target=run_flask, daemon=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
    flask_thread.start()
# @BLOODYNIGHTMODMENU code not for sell use own use
    time.sleep(2)
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("✅ Flask server started on port 5000")
