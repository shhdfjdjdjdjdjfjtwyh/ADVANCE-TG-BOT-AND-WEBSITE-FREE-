# @BLOODYNIGHTMODMENU code not for sell use own use
import json
# @BLOODYNIGHTMODMENU code not for sell use own use
import os
# @BLOODYNIGHTMODMENU code not for sell use own use
from datetime import datetime

# @BLOODYNIGHTMODMENU code not for sell use own use
DATA_FILE = "data.json"


# @BLOODYNIGHTMODMENU code not for sell use own use
def init_db():
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not os.path.exists(DATA_FILE):
# @BLOODYNIGHTMODMENU code not for sell use own use
        default_data = {
# @BLOODYNIGHTMODMENU code not for sell use own use
            "users": {},
# @BLOODYNIGHTMODMENU code not for sell use own use
            "images": {},   # {user_id: [{filename, url, date}]}
# @BLOODYNIGHTMODMENU code not for sell use own use
            "banned_users": [],
# @BLOODYNIGHTMODMENU code not for sell use own use
            "settings": {
# @BLOODYNIGHTMODMENU code not for sell use own use
                "tunnel_url": ""
# @BLOODYNIGHTMODMENU code not for sell use own use
            }
# @BLOODYNIGHTMODMENU code not for sell use own use
        }
# @BLOODYNIGHTMODMENU code not for sell use own use
        with open(DATA_FILE, 'w') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
            json.dump(default_data, f, indent=4)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return default_data
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        with open(DATA_FILE, 'r') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
            return json.load(f)
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        os.remove(DATA_FILE)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return init_db()


# @BLOODYNIGHTMODMENU code not for sell use own use
def load_data():
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        with open(DATA_FILE, 'r') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
            return json.load(f)
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return init_db()


# @BLOODYNIGHTMODMENU code not for sell use own use
def save_data(data):
# @BLOODYNIGHTMODMENU code not for sell use own use
    with open(DATA_FILE, 'w') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
        json.dump(data, f, indent=4)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# USER FUNCTIONS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def add_user(user_id, username, first_name):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid not in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid] = {
# @BLOODYNIGHTMODMENU code not for sell use own use
            "id": uid,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "username": username or "",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "first_name": first_name or "User",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "joined": datetime.now().strftime("%d-%m-%Y %H:%M"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            "banned": False,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "uploads": 0
# @BLOODYNIGHTMODMENU code not for sell use own use
        }
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["images"].setdefault(uid, [])
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["users"].get(str(user_id))


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_all_users():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["users"]


# @BLOODYNIGHTMODMENU code not for sell use own use
def ban_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid]["banned"] = True
# @BLOODYNIGHTMODMENU code not for sell use own use
        if uid not in data["banned_users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["banned_users"].append(uid)
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False


# @BLOODYNIGHTMODMENU code not for sell use own use
def unban_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid]["banned"] = False
# @BLOODYNIGHTMODMENU code not for sell use own use
        if uid in data["banned_users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["banned_users"].remove(uid)
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False


# @BLOODYNIGHTMODMENU code not for sell use own use
def is_banned(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return str(user_id) in data.get("banned_users", [])


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_users_count():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return len(data["users"])


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# IMAGE FUNCTIONS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def add_image(user_id, filename, url):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["images"].setdefault(uid, [])
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["images"][uid].append({
# @BLOODYNIGHTMODMENU code not for sell use own use
        "filename": filename,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "url": url,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "date": datetime.now().strftime("%d-%m-%Y %H:%M")
# @BLOODYNIGHTMODMENU code not for sell use own use
    })
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid]["uploads"] = data["users"][uid].get("uploads", 0) + 1
# @BLOODYNIGHTMODMENU code not for sell use own use
    save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return True


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_user_images(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["images"].get(str(user_id), [])


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_total_images():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    total = 0
# @BLOODYNIGHTMODMENU code not for sell use own use
    for uid, imgs in data["images"].items():
# @BLOODYNIGHTMODMENU code not for sell use own use
        total += len(imgs)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return total


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# SETTINGS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def set_tunnel_url(url):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["settings"]["tunnel_url"] = url
# @BLOODYNIGHTMODMENU code not for sell use own use
    save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return True


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_tunnel_url():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["settings"].get("tunnel_url", "")


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_stats():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return {
# @BLOODYNIGHTMODMENU code not for sell use own use
        "total_users": len(data["users"]),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "total_images": get_total_images(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "banned_users": len(data["banned_users"])
# @BLOODYNIGHTMODMENU code not for sell use own use
    }


# @BLOODYNIGHTMODMENU code not for sell use own use
init_db()
