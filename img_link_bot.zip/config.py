# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# IMG LINK BOT - CONFIG
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
BOT_TOKEN = ""
# @BLOODYNIGHTMODMENU code not for sell use own use
ADMIN_ID = 

# @BLOODYNIGHTMODMENU code not for sell use own use
# Folders
# @BLOODYNIGHTMODMENU code not for sell use own use
UPLOAD_FOLDER = "uploads"

# @BLOODYNIGHTMODMENU code not for sell use own use
# Server Config
# @BLOODYNIGHTMODMENU code not for sell use own use
FLASK_HOST = "0000"
# @BLOODYNIGHTMODMENU code not for sell use own use
FLASK_PORT = 0000

# @BLOODYNIGHTMODMENU code not for sell use own use
# Cloudflare Tunnel URL (auto-update hoga)
# @BLOODYNIGHTMODMENU code not for sell use own use
TUNNEL_URL = ""

# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# DEVELOPER
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
