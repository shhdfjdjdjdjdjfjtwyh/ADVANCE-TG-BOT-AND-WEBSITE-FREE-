# @BLOODYNIGHTMODMENU code not for sell use own use
import os
# @BLOODYNIGHTMODMENU code not for sell use own use
import uuid
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram.ext import ContextTypes
# @BLOODYNIGHTMODMENU code not for sell use own use
from database import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_user, get_user_images, add_image, get_tunnel_url
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from keyboards import main_menu, back_menu
# @BLOODYNIGHTMODMENU code not for sell use own use
from config import UPLOAD_FOLDER, DEVELOPER

# @BLOODYNIGHTMODMENU code not for sell use own use
# User states
# @BLOODYNIGHTMODMENU code not for sell use own use
user_states = {}


# @BLOODYNIGHTMODMENU code not for sell use own use
def set_state(user_id, state, **kwargs):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_states[user_id] = {"state": state, **kwargs}


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return user_states.get(user_id, {})


# @BLOODYNIGHTMODMENU code not for sell use own use
def clear_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_states.pop(user_id, None)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Start command"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = update.effective_user
# @BLOODYNIGHTMODMENU code not for sell use own use
    from config import ADMIN_ID
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    is_admin = user.id == ADMIN_ID
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👋 Welcome {user.first_name}!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🖼️ **Image to Link Bot**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📤 Send any image and get direct link!\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🔗 Fast • Free • Unlimited\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👇 Choose an option:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=main_menu(is_admin),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def gen_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Ask user to send image"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(user_id, "awaiting_image")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "📤 **Send me your image**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "✅ I will upload it and give you a direct link\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "🖼️ Supported: JPG, PNG, GIF, WEBP\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "📦 Max size: 20MB",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def my_links(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Show user's uploaded images"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    images = get_user_images(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not images:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "📁 **My Links**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "❌ You haven't uploaded any images yet!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Tap GEN LINK to start.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=main_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = f"📁 **My Links** ({len(images)})\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
    text += "━━━━━━━━━━━━━━━━━━━━━\n\n"
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    for i, img in enumerate(images[-10:], 1):
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += f"**#{i}** 📄 {img['filename']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += f"🔗 `{img['url']}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += f"📅 {img['date']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += "━━━━━━━━━━━━━━━━━━━━━\n"
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        text,
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=main_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def support(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Support info"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🆘 **Support**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📞 **Contact:** {DEVELOPER}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📌 For any issues:\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"• Link not working\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"• Upload failed\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"• File deleted\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"⏱️ Response: 15-30 minutes",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=main_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_image(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Handle image upload"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = get_user(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not user:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Please /start first")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Check banned
# @BLOODYNIGHTMODMENU code not for sell use own use
    from database import is_banned
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_banned(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🚫 **You are banned!**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Contact support for help.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Get image
# @BLOODYNIGHTMODMENU code not for sell use own use
    if update.message.photo:
# @BLOODYNIGHTMODMENU code not for sell use own use
        file = await update.message.photo[-1].get_file()
# @BLOODYNIGHTMODMENU code not for sell use own use
        ext = "jpg"
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif update.message.document:
# @BLOODYNIGHTMODMENU code not for sell use own use
        doc = update.message.document
# @BLOODYNIGHTMODMENU code not for sell use own use
        if not doc.mime_type or not doc.mime_type.startswith("image/"):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                "❌ Only images allowed!",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
# @BLOODYNIGHTMODMENU code not for sell use own use
        file = await doc.get_file()
# @BLOODYNIGHTMODMENU code not for sell use own use
        ext = doc.file_name.split(".")[-1] if "." in doc.file_name else "jpg"
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "❌ Please send an image!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Show processing
# @BLOODYNIGHTMODMENU code not for sell use own use
    msg = await update.message.reply_text("⏳ **Uploading...**", parse_mode="Markdown")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Create user folder
# @BLOODYNIGHTMODMENU code not for sell use own use
        user_folder = os.path.join(UPLOAD_FOLDER, str(user_id))
# @BLOODYNIGHTMODMENU code not for sell use own use
        os.makedirs(user_folder, exist_ok=True)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Generate unique filename
# @BLOODYNIGHTMODMENU code not for sell use own use
        unique_id = str(uuid.uuid4())[:8]
# @BLOODYNIGHTMODMENU code not for sell use own use
        filename = f"{unique_id}.{ext}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        filepath = os.path.join(user_folder, filename)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Download
# @BLOODYNIGHTMODMENU code not for sell use own use
        await file.download_to_drive(filepath)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Get tunnel URL
# @BLOODYNIGHTMODMENU code not for sell use own use
        tunnel_url = get_tunnel_url()
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        if not tunnel_url:
# @BLOODYNIGHTMODMENU code not for sell use own use
            from server import get_url
# @BLOODYNIGHTMODMENU code not for sell use own use
            tunnel_url = get_url()
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        if not tunnel_url:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await msg.edit_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                "❌ **Server not ready!**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                "Tunnel is starting. Please try again in 30 seconds.",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Generate link
# @BLOODYNIGHTMODMENU code not for sell use own use
        link = f"{tunnel_url}/img/{user_id}/{filename}"
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Save to DB
# @BLOODYNIGHTMODMENU code not for sell use own use
        add_image(user_id, filename, link)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Delete processing message
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await msg.delete()
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Inline buttons for link
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard = InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
            [InlineKeyboardButton("🔗 Open Link", url=link, style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
            [InlineKeyboardButton("📋 Copy Link", callback_data=f"copy_{filename}", style="primary")]
# @BLOODYNIGHTMODMENU code not for sell use own use
        ])
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Success message with inline buttons
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ **Upload Successful!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📄 **File:** `{filename}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🔗 **Link:**\n`{link}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📌 Tap the link to copy\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🔗 Direct link works anywhere!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=keyboard,
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Send main menu as separate message
# @BLOODYNIGHTMODMENU code not for sell use own use
        from config import ADMIN_ID
# @BLOODYNIGHTMODMENU code not for sell use own use
        is_admin = user_id == int(ADMIN_ID)
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "👇 Use menu below:",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=main_menu(is_admin)
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
    except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await msg.delete()
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ **Upload Failed!**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Error: `{str(e)[:200]}`",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Handle menu button clicks"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = update.message.text
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    from config import ADMIN_ID
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    is_admin = user_id == ADMIN_ID
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if text == "🔗 GEN LINK":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await gen_link(update, context)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "📁 MY LINKS":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await my_links(update, context)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "🆘 SUPPORT":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await support(update, context)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "🔐 ADMIN PANEL" and is_admin:
# @BLOODYNIGHTMODMENU code not for sell use own use
        from handlers.admin import admin_panel
# @BLOODYNIGHTMODMENU code not for sell use own use
        await admin_panel(update, context)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Check if awaiting image state
# @BLOODYNIGHTMODMENU code not for sell use own use
        state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
        if state.get("state") == "awaiting_image":
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_image(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
        else:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                "⚠️ Unknown command! Use menu below.",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=main_menu(is_admin)
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
