# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram.ext import ContextTypes
# @BLOODYNIGHTMODMENU code not for sell use own use
from config import ADMIN_ID
# @BLOODYNIGHTMODMENU code not for sell use own use
from database import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_all_users, get_user, ban_user, unban_user, is_banned,
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_stats, get_users_count
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from keyboards import admin_menu, main_menu, user_list_inline, user_detail_inline, back_menu


# @BLOODYNIGHTMODMENU code not for sell use own use
def is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return user_id == ADMIN_ID


# @BLOODYNIGHTMODMENU code not for sell use own use
# Admin states
# @BLOODYNIGHTMODMENU code not for sell use own use
admin_states = {}


# @BLOODYNIGHTMODMENU code not for sell use own use
def set_state(user_id, state, **kwargs):
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_states[user_id] = {"state": state, **kwargs}


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return admin_states.get(user_id, {})


# @BLOODYNIGHTMODMENU code not for sell use own use
def clear_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_states.pop(user_id, None)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Show admin panel"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "🔐 **ADMIN PANEL**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Choose an option:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=admin_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Show stats"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    stats = get_stats()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📊 **STATS**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👥 Total Users: {stats['total_users']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🖼️ Total Images: {stats['total_images']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🚫 Banned Users: {stats['banned_users']}",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=admin_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def view_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Show users list"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    users = get_all_users()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not users:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "👥 **Users**\n\n❌ No users found!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=admin_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👥 **All Users** ({len(users)})\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"Tap a user to view:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=user_list_inline(users, 0),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def ban_user_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Ban user - ask for ID"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_ban_id")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "🚫 **BAN USER**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Send user ID to ban:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def unban_user_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Unban user - ask for ID"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_unban_id")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "✅ **UNBAN USER**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Send user ID to unban:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def broadcast_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Broadcast - ask for message"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_broadcast")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "📢 **BROADCAST**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Send message to broadcast to all users:\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "✅ Text\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "✅ Image with caption\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "✅ Image only",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Handle broadcast message"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_broadcast":
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    users = get_all_users()
# @BLOODYNIGHTMODMENU code not for sell use own use
    total = len(users)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    msg = await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"⏳ **Broadcasting to {total} users...**",
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    sent = 0
# @BLOODYNIGHTMODMENU code not for sell use own use
    failed = 0
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Check if message has image
# @BLOODYNIGHTMODMENU code not for sell use own use
    has_image = bool(update.message.photo or update.message.document)
# @BLOODYNIGHTMODMENU code not for sell use own use
    caption = update.message.caption or update.message.text or ""
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    for uid in users.keys():
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            if has_image:
# @BLOODYNIGHTMODMENU code not for sell use own use
                # Send image
# @BLOODYNIGHTMODMENU code not for sell use own use
                if update.message.photo:
# @BLOODYNIGHTMODMENU code not for sell use own use
                    photo = update.message.photo[-1].file_id
# @BLOODYNIGHTMODMENU code not for sell use own use
                    await context.bot.send_photo(
# @BLOODYNIGHTMODMENU code not for sell use own use
                        chat_id=int(uid),
# @BLOODYNIGHTMODMENU code not for sell use own use
                        photo=photo,
# @BLOODYNIGHTMODMENU code not for sell use own use
                        caption=caption
# @BLOODYNIGHTMODMENU code not for sell use own use
                    )
# @BLOODYNIGHTMODMENU code not for sell use own use
                elif update.message.document:
# @BLOODYNIGHTMODMENU code not for sell use own use
                    doc = update.message.document.file_id
# @BLOODYNIGHTMODMENU code not for sell use own use
                    await context.bot.send_document(
# @BLOODYNIGHTMODMENU code not for sell use own use
                        chat_id=int(uid),
# @BLOODYNIGHTMODMENU code not for sell use own use
                        document=doc,
# @BLOODYNIGHTMODMENU code not for sell use own use
                        caption=caption
# @BLOODYNIGHTMODMENU code not for sell use own use
                    )
# @BLOODYNIGHTMODMENU code not for sell use own use
            else:
# @BLOODYNIGHTMODMENU code not for sell use own use
                # Text only
# @BLOODYNIGHTMODMENU code not for sell use own use
                await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    chat_id=int(uid),
# @BLOODYNIGHTMODMENU code not for sell use own use
                    text=caption
# @BLOODYNIGHTMODMENU code not for sell use own use
                )
# @BLOODYNIGHTMODMENU code not for sell use own use
            sent += 1
# @BLOODYNIGHTMODMENU code not for sell use own use
        except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
            failed += 1
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await msg.edit_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"✅ **Broadcast Complete!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"✅ Sent: {sent}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"❌ Failed: {failed}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📊 Total: {total}",
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_ban_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Handle ban ID input"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") not in ("awaiting_ban_id", "awaiting_unban_id"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    target_id = update.message.text.strip()
# @BLOODYNIGHTMODMENU code not for sell use own use
    target_user = get_user(target_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not target_user:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ User `{target_id}` not found!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=admin_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") == "awaiting_ban_id":
# @BLOODYNIGHTMODMENU code not for sell use own use
        if ban_user(target_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"✅ User banned!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👤 {target_user.get('first_name')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🆔 `{target_id}`",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=admin_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            # Notify user
# @BLOODYNIGHTMODMENU code not for sell use own use
            try:
# @BLOODYNIGHTMODMENU code not for sell use own use
                await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    chat_id=int(target_id),
# @BLOODYNIGHTMODMENU code not for sell use own use
                    text="🚫 You have been banned!\n\nContact support for help."
# @BLOODYNIGHTMODMENU code not for sell use own use
                )
# @BLOODYNIGHTMODMENU code not for sell use own use
            except:
# @BLOODYNIGHTMODMENU code not for sell use own use
                pass
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        if unban_user(target_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"✅ User unbanned!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👤 {target_user.get('first_name')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🆔 `{target_id}`",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=admin_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            # Notify user
# @BLOODYNIGHTMODMENU code not for sell use own use
            try:
# @BLOODYNIGHTMODMENU code not for sell use own use
                await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    chat_id=int(target_id),
# @BLOODYNIGHTMODMENU code not for sell use own use
                    text="✅ You have been unbanned!\n\nYou can use the bot now."
# @BLOODYNIGHTMODMENU code not for sell use own use
                )
# @BLOODYNIGHTMODMENU code not for sell use own use
            except:
# @BLOODYNIGHTMODMENU code not for sell use own use
                pass
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Handle admin inline callbacks"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = query.data
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Admin only!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # User page navigation
# @BLOODYNIGHTMODMENU code not for sell use own use
    if data.startswith("userpage_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        page = int(data.split("_")[1])
# @BLOODYNIGHTMODMENU code not for sell use own use
        users = get_all_users()
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_reply_markup(
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_list_inline(users, page)
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # View user detail
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("user_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        uid = data.split("_")[1]
# @BLOODYNIGHTMODMENU code not for sell use own use
        user = get_user(uid)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        if not user:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await query.edit_message_text("❌ User not found!")
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        status = "🚫 BANNED" if user.get("banned") else "✅ ACTIVE"
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        text = (
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"👤 **USER DETAILS**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🆔 **ID:** `{uid}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"👤 **Name:** {user.get('first_name', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📝 **Username:** @{user.get('username', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📅 **Joined:** {user.get('joined', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🖼️ **Uploads:** {user.get('uploads', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🚦 **Status:** {status}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            text,
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_detail_inline(uid, user.get("banned", False)),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Ban user
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("ban_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        uid = data.split("_")[1]
# @BLOODYNIGHTMODMENU code not for sell use own use
        if ban_user(uid):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await query.answer("🚫 User banned!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
            # Refresh detail
# @BLOODYNIGHTMODMENU code not for sell use own use
            context.user_data["_refresh_user"] = uid
# @BLOODYNIGHTMODMENU code not for sell use own use
            fake_data = f"user_{uid}"
# @BLOODYNIGHTMODMENU code not for sell use own use
            class FakeQuery:
# @BLOODYNIGHTMODMENU code not for sell use own use
                def __init__(self, q):
# @BLOODYNIGHTMODMENU code not for sell use own use
                    self.callback_query = q
# @BLOODYNIGHTMODMENU code not for sell use own use
                    self.effective_user = q.from_user
# @BLOODYNIGHTMODMENU code not for sell use own use
                async def answer(self, *a, **k):
# @BLOODYNIGHTMODMENU code not for sell use own use
                    pass
# @BLOODYNIGHTMODMENU code not for sell use own use
            # Just show again
# @BLOODYNIGHTMODMENU code not for sell use own use
            user = get_user(uid)
# @BLOODYNIGHTMODMENU code not for sell use own use
            status = "🚫 BANNED"
# @BLOODYNIGHTMODMENU code not for sell use own use
            text = (
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👤 **USER DETAILS**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🆔 **ID:** `{uid}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👤 **Name:** {user.get('first_name', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"📝 **Username:** @{user.get('username', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"📅 **Joined:** {user.get('joined', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🖼️ **Uploads:** {user.get('uploads', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🚦 **Status:** {status}"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                text,
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=user_detail_inline(uid, True),
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            # Notify
# @BLOODYNIGHTMODMENU code not for sell use own use
            try:
# @BLOODYNIGHTMODMENU code not for sell use own use
                await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    chat_id=int(uid),
# @BLOODYNIGHTMODMENU code not for sell use own use
                    text="🚫 You have been banned!"
# @BLOODYNIGHTMODMENU code not for sell use own use
                )
# @BLOODYNIGHTMODMENU code not for sell use own use
            except:
# @BLOODYNIGHTMODMENU code not for sell use own use
                pass
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Unban user
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("unban_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        uid = data.split("_")[1]
# @BLOODYNIGHTMODMENU code not for sell use own use
        if unban_user(uid):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await query.answer("✅ User unbanned!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
            user = get_user(uid)
# @BLOODYNIGHTMODMENU code not for sell use own use
            status = "✅ ACTIVE"
# @BLOODYNIGHTMODMENU code not for sell use own use
            text = (
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👤 **USER DETAILS**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🆔 **ID:** `{uid}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👤 **Name:** {user.get('first_name', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"📝 **Username:** @{user.get('username', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"📅 **Joined:** {user.get('joined', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🖼️ **Uploads:** {user.get('uploads', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🚦 **Status:** {status}"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                text,
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=user_detail_inline(uid, False),
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
            # Notify
# @BLOODYNIGHTMODMENU code not for sell use own use
            try:
# @BLOODYNIGHTMODMENU code not for sell use own use
                await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    chat_id=int(uid),
# @BLOODYNIGHTMODMENU code not for sell use own use
                    text="✅ You have been unbanned!"
# @BLOODYNIGHTMODMENU code not for sell use own use
                )
# @BLOODYNIGHTMODMENU code not for sell use own use
            except:
# @BLOODYNIGHTMODMENU code not for sell use own use
                pass
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Back to users list
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "view_users":
# @BLOODYNIGHTMODMENU code not for sell use own use
        users = get_all_users()
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"👥 **All Users** ({len(users)})\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Tap a user to view:",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_list_inline(users, 0),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Close menu
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "close_menu":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.delete_message()


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_admin_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Handle admin menu clicks"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = update.message.text
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if text == "🚫 BAN USER":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await ban_user_menu(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "✅ UNBAN USER":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await unban_user_menu(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "👥 VIEW USERS":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await view_users(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "📢 BROADCAST":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await broadcast_menu(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "📊 STATS":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await stats(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif text == "🔙 BACK":
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🏠 Back to main menu!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=main_menu(True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Check state
# @BLOODYNIGHTMODMENU code not for sell use own use
        state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
        if state.get("state") in ("awaiting_ban_id", "awaiting_unban_id"):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_ban_input(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
        elif state.get("state") == "awaiting_broadcast":
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_broadcast(update, context)
