# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup


# @BLOODYNIGHTMODMENU code not for sell use own use
def main_menu(is_admin=False):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Main menu - custom keyboard with colors"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    rows = [
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            KeyboardButton("🔗 GEN LINK", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            KeyboardButton("📁 MY LINKS", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            KeyboardButton("🆘 SUPPORT", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_admin:
# @BLOODYNIGHTMODMENU code not for sell use own use
        rows.append([
# @BLOODYNIGHTMODMENU code not for sell use own use
            KeyboardButton("🔐 ADMIN PANEL", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return ReplyKeyboardMarkup(
# @BLOODYNIGHTMODMENU code not for sell use own use
        rows,
# @BLOODYNIGHTMODMENU code not for sell use own use
        resize_keyboard=True,
# @BLOODYNIGHTMODMENU code not for sell use own use
        one_time_keyboard=False
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
def admin_menu():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Admin menu"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return ReplyKeyboardMarkup(
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            [
# @BLOODYNIGHTMODMENU code not for sell use own use
                KeyboardButton("🚫 BAN USER", style="danger"),
# @BLOODYNIGHTMODMENU code not for sell use own use
                KeyboardButton("✅ UNBAN USER", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
            ],
# @BLOODYNIGHTMODMENU code not for sell use own use
            [
# @BLOODYNIGHTMODMENU code not for sell use own use
                KeyboardButton("👥 VIEW USERS", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
                KeyboardButton("📢 BROADCAST", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
            ],
# @BLOODYNIGHTMODMENU code not for sell use own use
            [
# @BLOODYNIGHTMODMENU code not for sell use own use
                KeyboardButton("📊 STATS", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
            ],
# @BLOODYNIGHTMODMENU code not for sell use own use
            [
# @BLOODYNIGHTMODMENU code not for sell use own use
                KeyboardButton("🔙 BACK", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
            ]
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        resize_keyboard=True,
# @BLOODYNIGHTMODMENU code not for sell use own use
        one_time_keyboard=False
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
def back_menu():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Back button only"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return ReplyKeyboardMarkup(
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            [KeyboardButton("🔙 BACK", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        resize_keyboard=True,
# @BLOODYNIGHTMODMENU code not for sell use own use
        one_time_keyboard=True
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
def user_list_inline(users, page=0, per_page=10):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User list with inline buttons"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    items = list(users.items())
# @BLOODYNIGHTMODMENU code not for sell use own use
    start = page * per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    end = start + per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    page_items = items[start:end]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    for uid, u in page_items:
# @BLOODYNIGHTMODMENU code not for sell use own use
        status = "🚫" if u.get("banned") else "✅"
# @BLOODYNIGHTMODMENU code not for sell use own use
        name = u.get("first_name", "User")[:15]
# @BLOODYNIGHTMODMENU code not for sell use own use
        btn_text = f"{status} {name} | {uid}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append([InlineKeyboardButton(
# @BLOODYNIGHTMODMENU code not for sell use own use
            btn_text,
# @BLOODYNIGHTMODMENU code not for sell use own use
            callback_data=f"user_{uid}",
# @BLOODYNIGHTMODMENU code not for sell use own use
            style="success" if not u.get("banned") else "danger"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    nav = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    if page > 0:
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("⬅️", callback_data=f"userpage_{page-1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if end < len(items):
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("➡️", callback_data=f"userpage_{page+1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if nav:
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append(nav)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard.append([InlineKeyboardButton("❌ CLOSE", callback_data="close_menu", style="danger")])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup(keyboard)


# @BLOODYNIGHTMODMENU code not for sell use own use
def user_detail_inline(user_id, is_banned):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User detail actions"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    ban_btn = (
# @BLOODYNIGHTMODMENU code not for sell use own use
        InlineKeyboardButton("✅ UNBAN", callback_data=f"unban_{user_id}", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        if is_banned else
# @BLOODYNIGHTMODMENU code not for sell use own use
        InlineKeyboardButton("🚫 BAN", callback_data=f"ban_{user_id}", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
    )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [ban_btn],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🔙 BACK", callback_data="view_users", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])
