# @BLOODYNIGHTMODMENU code not for sell use own use
#!/usr/bin/env python3
# @BLOODYNIGHTMODMENU code not for sell use own use
import asyncio
# @BLOODYNIGHTMODMENU code not for sell use own use
import logging
# @BLOODYNIGHTMODMENU code not for sell use own use
import os
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import Update
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram.ext import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    Application, CommandHandler, MessageHandler, CallbackQueryHandler,
# @BLOODYNIGHTMODMENU code not for sell use own use
    filters, ContextTypes
# @BLOODYNIGHTMODMENU code not for sell use own use
)

# @BLOODYNIGHTMODMENU code not for sell use own use
from config import BOT_TOKEN, ADMIN_ID
# @BLOODYNIGHTMODMENU code not for sell use own use
from database import add_user, is_banned, init_db
# @BLOODYNIGHTMODMENU code not for sell use own use
from handlers.user import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    start, gen_link, my_links, support, handle_text, handle_image,
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_state as user_get_state
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from handlers.admin import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_panel, admin_callback, handle_admin_text,
# @BLOODYNIGHTMODMENU code not for sell use own use
    is_admin, get_state as admin_get_state
# @BLOODYNIGHTMODMENU code not for sell use own use
)

# @BLOODYNIGHTMODMENU code not for sell use own use
logging.basicConfig(
# @BLOODYNIGHTMODMENU code not for sell use own use
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
# @BLOODYNIGHTMODMENU code not for sell use own use
    level=logging.INFO
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
logger = logging.getLogger(__name__)

# @BLOODYNIGHTMODMENU code not for sell use own use
init_db()


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# START COMMAND
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = update.effective_user
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Check banned
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_banned(user.id) and not is_admin(user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🚫 You are banned!\n\nContact support for help."
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Add user
# @BLOODYNIGHTMODMENU code not for sell use own use
    add_user(user.id, user.username, user.first_name)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await start(update, context)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# MESSAGE ROUTER
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
async def message_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Check banned
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_banned(user_id) and not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("🚫 You are banned!")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Add user
# @BLOODYNIGHTMODMENU code not for sell use own use
    add_user(user_id, update.effective_user.username, update.effective_user.first_name)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Get states
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_state = user_get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_state = admin_get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Admin states
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        if admin_state.get("state") in ("awaiting_ban_id", "awaiting_unban_id", "awaiting_broadcast"):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_admin_text(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Admin menu clicks
# @BLOODYNIGHTMODMENU code not for sell use own use
        if update.message.text in (
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🚫 BAN USER", "✅ UNBAN USER", "👥 VIEW USERS",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "📢 BROADCAST", "📊 STATS", "🔙 BACK", "🔐 ADMIN PANEL"
# @BLOODYNIGHTMODMENU code not for sell use own use
        ):
# @BLOODYNIGHTMODMENU code not for sell use own use
            if update.message.text == "🔐 ADMIN PANEL":
# @BLOODYNIGHTMODMENU code not for sell use own use
                await admin_panel(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            else:
# @BLOODYNIGHTMODMENU code not for sell use own use
                await handle_admin_text(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Handle image
# @BLOODYNIGHTMODMENU code not for sell use own use
    if update.message.photo or (update.message.document and 
# @BLOODYNIGHTMODMENU code not for sell use own use
                                 update.message.document.mime_type and 
# @BLOODYNIGHTMODMENU code not for sell use own use
                                 update.message.document.mime_type.startswith("image/")):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await handle_image(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Handle text
# @BLOODYNIGHTMODMENU code not for sell use own use
    if update.message.text:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await handle_text(update, context)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# CALLBACK ROUTER
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = query.data
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Copy link
# @BLOODYNIGHTMODMENU code not for sell use own use
    if data.startswith("copy_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("📋 Link sent above!", show_alert=False)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Admin callbacks
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        if (data.startswith("user_") or data.startswith("userpage_") or 
# @BLOODYNIGHTMODMENU code not for sell use own use
            data.startswith("ban_") or data.startswith("unban_") or
# @BLOODYNIGHTMODMENU code not for sell use own use
            data in ("view_users", "close_menu")):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await admin_callback(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# MAIN
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
async def main():
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("🖼️ IMG LINK BOT STARTING...")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Start Flask server
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("🌐 Starting Flask server...")
# @BLOODYNIGHTMODMENU code not for sell use own use
    from server import start_server
# @BLOODYNIGHTMODMENU code not for sell use own use
    start_server()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Start Cloudflare Tunnel
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("🚀 Starting Cloudflare Tunnel...")
# @BLOODYNIGHTMODMENU code not for sell use own use
    from server import start_tunnel, get_url
# @BLOODYNIGHTMODMENU code not for sell use own use
    tunnel = start_tunnel()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if tunnel:
# @BLOODYNIGHTMODMENU code not for sell use own use
        print(f"✅ Tunnel: {tunnel}")
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        print("⚠️ Tunnel not ready yet (will update in background)")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Start Telegram Bot
# @BLOODYNIGHTMODMENU code not for sell use own use
    application = Application.builder().token(BOT_TOKEN).build()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    application.add_handler(CommandHandler("start", start_command))
# @BLOODYNIGHTMODMENU code not for sell use own use
    application.add_handler(CallbackQueryHandler(callback_router))
# @BLOODYNIGHTMODMENU code not for sell use own use
    application.add_handler(MessageHandler(
# @BLOODYNIGHTMODMENU code not for sell use own use
        filters.ALL & ~filters.COMMAND,
# @BLOODYNIGHTMODMENU code not for sell use own use
        message_router
# @BLOODYNIGHTMODMENU code not for sell use own use
    ))
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("🤖 BOT RUNNING!")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
# @BLOODYNIGHTMODMENU code not for sell use own use
    print(f"✅ Flask: http://localhost:5000")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print(f"✅ Tunnel: {get_url() or 'starting...'}")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print(f"✅ Admin ID: {ADMIN_ID}")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await application.initialize()
# @BLOODYNIGHTMODMENU code not for sell use own use
    await application.start()
# @BLOODYNIGHTMODMENU code not for sell use own use
    await application.updater.start_polling()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        while True:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await asyncio.sleep(1)
# @BLOODYNIGHTMODMENU code not for sell use own use
    except KeyboardInterrupt:
# @BLOODYNIGHTMODMENU code not for sell use own use
        print("\nBot stopped!")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await application.updater.stop()
# @BLOODYNIGHTMODMENU code not for sell use own use
        await application.stop()
# @BLOODYNIGHTMODMENU code not for sell use own use
        await application.shutdown()


# @BLOODYNIGHTMODMENU code not for sell use own use
if __name__ == "__main__":
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        asyncio.run(main())
# @BLOODYNIGHTMODMENU code not for sell use own use
    except KeyboardInterrupt:
# @BLOODYNIGHTMODMENU code not for sell use own use
        print("\nBot stopped by user!")
