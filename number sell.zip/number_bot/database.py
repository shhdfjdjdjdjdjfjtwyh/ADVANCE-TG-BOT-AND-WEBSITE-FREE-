# @BLOODYNIGHTMODMENU code not for sell use own use
import json
# @BLOODYNIGHTMODMENU code not for sell use own use
import os
# @BLOODYNIGHTMODMENU code not for sell use own use
from datetime import datetime
# @BLOODYNIGHTMODMENU code not for sell use own use
from config import DATA_FILE

# @BLOODYNIGHTMODMENU code not for sell use own use
def init_db():
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not os.path.exists(DATA_FILE):
# @BLOODYNIGHTMODMENU code not for sell use own use
        default_data = {
# @BLOODYNIGHTMODMENU code not for sell use own use
            "users": {},
# @BLOODYNIGHTMODMENU code not for sell use own use
            "sessions": {},
# @BLOODYNIGHTMODMENU code not for sell use own use
            "numbers_sold": [],
# @BLOODYNIGHTMODMENU code not for sell use own use
            "pending_payments": [],
# @BLOODYNIGHTMODMENU code not for sell use own use
            "payment_channels": [],
# @BLOODYNIGHTMODMENU code not for sell use own use
            "country_prices": {
# @BLOODYNIGHTMODMENU code not for sell use own use
                "US": {"flag": "🇺🇸", "name": "United States", "price": 50},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "IN": {"flag": "🇮🇳", "name": "India", "price": 30},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "UK": {"flag": "🇬🇧", "name": "United Kingdom", "price": 60},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "CA": {"flag": "🇨🇦", "name": "Canada", "price": 55},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "AU": {"flag": "🇦🇺", "name": "Australia", "price": 65},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "DE": {"flag": "🇩🇪", "name": "Germany", "price": 70},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "FR": {"flag": "🇫🇷", "name": "France", "price": 70},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "RU": {"flag": "🇷🇺", "name": "Russia", "price": 40},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "ID": {"flag": "🇮🇩", "name": "Indonesia", "price": 25},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "PH": {"flag": "🇵🇭", "name": "Philippines", "price": 25},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "BD": {"flag": "🇧🇩", "name": "Bangladesh", "price": 20},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "PK": {"flag": "🇵🇰", "name": "Pakistan", "price": 20},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "NG": {"flag": "🇳🇬", "name": "Nigeria", "price": 30},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "BR": {"flag": "🇧🇷", "name": "Brazil", "price": 35},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "MX": {"flag": "🇲🇽", "name": "Mexico", "price": 35},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "ZA": {"flag": "🇿🇦", "name": "South Africa", "price": 30},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "EG": {"flag": "🇪🇬", "name": "Egypt", "price": 25},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "SA": {"flag": "🇸🇦", "name": "Saudi Arabia", "price": 45},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "AE": {"flag": "🇦🇪", "name": "UAE", "price": 50},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "TR": {"flag": "🇹🇷", "name": "Turkey", "price": 35},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "IT": {"flag": "🇮🇹", "name": "Italy", "price": 65},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "ES": {"flag": "🇪🇸", "name": "Spain", "price": 60},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "NL": {"flag": "🇳🇱", "name": "Netherlands", "price": 70},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "BE": {"flag": "🇧🇪", "name": "Belgium", "price": 70},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "CH": {"flag": "🇨🇭", "name": "Switzerland", "price": 80},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "SE": {"flag": "🇸🇪", "name": "Sweden", "price": 75},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "NO": {"flag": "🇳🇴", "name": "Norway", "price": 75},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "DK": {"flag": "🇩🇰", "name": "Denmark", "price": 75},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "FI": {"flag": "🇫🇮", "name": "Finland", "price": 75},
# @BLOODYNIGHTMODMENU code not for sell use own use
                "PL": {"flag": "🇵🇱", "name": "Poland", "price": 45},
# @BLOODYNIGHTMODMENU code not for sell use own use
            },
# @BLOODYNIGHTMODMENU code not for sell use own use
            "banned_users": [],
# @BLOODYNIGHTMODMENU code not for sell use own use
            "settings": {
# @BLOODYNIGHTMODMENU code not for sell use own use
                "min_withdraw": 50
# @BLOODYNIGHTMODMENU code not for sell use own use
            }
# @BLOODYNIGHTMODMENU code not for sell use own use
        }
# @BLOODYNIGHTMODMENU code not for sell use own use
        with open(DATA_FILE, 'w') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
            json.dump(default_data, f, indent=4)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return default_data
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        with open(DATA_FILE, 'r') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
            return json.load(f)
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        os.remove(DATA_FILE)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return init_db()

# @BLOODYNIGHTMODMENU code not for sell use own use
def load_data():
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        with open(DATA_FILE, 'r') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
            return json.load(f)
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return init_db()

# @BLOODYNIGHTMODMENU code not for sell use own use
def save_data(data):
# @BLOODYNIGHTMODMENU code not for sell use own use
    with open(DATA_FILE, 'w') as f:
# @BLOODYNIGHTMODMENU code not for sell use own use
        json.dump(data, f, indent=4)

# @BLOODYNIGHTMODMENU code not for sell use own use
# USER FUNCTIONS
# @BLOODYNIGHTMODMENU code not for sell use own use
def add_user(user_id, username, first_name):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid not in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid] = {
# @BLOODYNIGHTMODMENU code not for sell use own use
            "id": uid,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "username": username or "",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "first_name": first_name or "User",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "balance": 0,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "total_earned": 0,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "total_withdrawn": 0,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "numbers_sold": 0,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "joined": datetime.now().strftime("%d-%m-%Y %H:%M"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            "banned": False,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "upi_id": "",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "bank_account": "",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "binance_id": "",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "trx20_address": "",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "bep20_address": "",
# @BLOODYNIGHTMODMENU code not for sell use own use
            "withdraw_method": ""
# @BLOODYNIGHTMODMENU code not for sell use own use
        }
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["users"].get(str(user_id))

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_all_users():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["users"]

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_balance(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = get_user(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return user.get("balance", 0) if user else 0

# @BLOODYNIGHTMODMENU code not for sell use own use
def add_balance(user_id, amount):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid]["balance"] += amount
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid]["total_earned"] += amount
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def deduct_balance(user_id, amount):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        if data["users"][uid]["balance"] >= amount:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["balance"] -= amount
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["total_withdrawn"] += amount
# @BLOODYNIGHTMODMENU code not for sell use own use
            save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def ban_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid]["banned"] = True
# @BLOODYNIGHTMODMENU code not for sell use own use
        if uid not in data["banned_users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["banned_users"].append(uid)
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def unban_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][uid]["banned"] = False
# @BLOODYNIGHTMODMENU code not for sell use own use
        if uid in data["banned_users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["banned_users"].remove(uid)
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def is_banned(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return str(user_id) in data.get("banned_users", [])

# @BLOODYNIGHTMODMENU code not for sell use own use
def update_user_payment(user_id, upi_id="", bank_account="", binance_id="", trx20_address="", bep20_address="", method=""):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if uid in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        if upi_id:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["upi_id"] = upi_id
# @BLOODYNIGHTMODMENU code not for sell use own use
        if bank_account:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["bank_account"] = bank_account
# @BLOODYNIGHTMODMENU code not for sell use own use
        if binance_id:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["binance_id"] = binance_id
# @BLOODYNIGHTMODMENU code not for sell use own use
        if trx20_address:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["trx20_address"] = trx20_address
# @BLOODYNIGHTMODMENU code not for sell use own use
        if bep20_address:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["bep20_address"] = bep20_address
# @BLOODYNIGHTMODMENU code not for sell use own use
        if method:
# @BLOODYNIGHTMODMENU code not for sell use own use
            data["users"][uid]["withdraw_method"] = method
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def create_session(user_id, session_data):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["sessions"][str(user_id)] = session_data
# @BLOODYNIGHTMODMENU code not for sell use own use
    save_data(data)

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_session(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["sessions"].get(str(user_id))

# @BLOODYNIGHTMODMENU code not for sell use own use
def delete_session(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    if str(user_id) in data["sessions"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        del data["sessions"][str(user_id)]
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def add_sold_number(user_id, country, phone, price, otp=""):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["numbers_sold"].append({
# @BLOODYNIGHTMODMENU code not for sell use own use
        "user_id": str(user_id),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "country": country,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "phone": phone,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "price": price,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "otp": otp,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "date": datetime.now().strftime("%d-%m-%Y %H:%M"),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "status": "completed"
# @BLOODYNIGHTMODMENU code not for sell use own use
    })
# @BLOODYNIGHTMODMENU code not for sell use own use
    if str(user_id) in data["users"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["users"][str(user_id)]["numbers_sold"] += 1
# @BLOODYNIGHTMODMENU code not for sell use own use
    save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return True

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_user_history(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return [n for n in data["numbers_sold"] if n["user_id"] == uid]

# @BLOODYNIGHTMODMENU code not for sell use own use
def add_pending_payment(user_id, amount, method, account):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    order_id = f"WD{datetime.now().strftime('%Y%m%d%H%M%S')}"
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["pending_payments"].append({
# @BLOODYNIGHTMODMENU code not for sell use own use
        "order_id": order_id,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "user_id": str(user_id),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "amount": amount,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "method": method,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "account": account,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "status": "pending",
# @BLOODYNIGHTMODMENU code not for sell use own use
        "date": datetime.now().strftime("%d-%m-%Y %H:%M")
# @BLOODYNIGHTMODMENU code not for sell use own use
    })
# @BLOODYNIGHTMODMENU code not for sell use own use
    save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return order_id

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_pending_payments():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return [p for p in data["pending_payments"] if p["status"] == "pending"]

# @BLOODYNIGHTMODMENU code not for sell use own use
def approve_payment(order_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    for p in data["pending_payments"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        if p["order_id"] == order_id:
# @BLOODYNIGHTMODMENU code not for sell use own use
            p["status"] = "approved"
# @BLOODYNIGHTMODMENU code not for sell use own use
            save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return p
# @BLOODYNIGHTMODMENU code not for sell use own use
    return None

# @BLOODYNIGHTMODMENU code not for sell use own use
def reject_payment(order_id, reason="Rejected"):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    for p in data["pending_payments"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        if p["order_id"] == order_id:
# @BLOODYNIGHTMODMENU code not for sell use own use
            p["status"] = "rejected"
# @BLOODYNIGHTMODMENU code not for sell use own use
            p["reason"] = reason
# @BLOODYNIGHTMODMENU code not for sell use own use
            save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return p
# @BLOODYNIGHTMODMENU code not for sell use own use
    return None

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_user_payments(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    uid = str(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return [p for p in data["pending_payments"] if p["user_id"] == uid]

# @BLOODYNIGHTMODMENU code not for sell use own use
def add_payment_channel(channel_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    if channel_id not in data["payment_channels"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["payment_channels"].append(channel_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def remove_payment_channel(channel_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    if channel_id in data["payment_channels"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["payment_channels"].remove(channel_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_payment_channels():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["payment_channels"]

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_all_prices():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["country_prices"]

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_price(country_code):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["country_prices"].get(country_code, {}).get("price", 0)

# @BLOODYNIGHTMODMENU code not for sell use own use
def set_price(country_code, price):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    if country_code in data["country_prices"]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        data["country_prices"][country_code]["price"] = price
# @BLOODYNIGHTMODMENU code not for sell use own use
        save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    return False

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_stats():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    total_sold = len(data["numbers_sold"])
# @BLOODYNIGHTMODMENU code not for sell use own use
    total_earned = sum(n.get("price", 0) for n in data["numbers_sold"])
# @BLOODYNIGHTMODMENU code not for sell use own use
    return {
# @BLOODYNIGHTMODMENU code not for sell use own use
        "total_users": len(data["users"]),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "total_sold": total_sold,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "total_earned": total_earned,
# @BLOODYNIGHTMODMENU code not for sell use own use
        "pending_withdrawals": len([p for p in data["pending_payments"] if p["status"] == "pending"])
# @BLOODYNIGHTMODMENU code not for sell use own use
    }

# @BLOODYNIGHTMODMENU code not for sell use own use
init_db()


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# MIN WITHDRAW SETTINGS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def get_min_withdraw():
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    return data["settings"].get("min_withdraw", 50)


# @BLOODYNIGHTMODMENU code not for sell use own use
def set_min_withdraw(amount):
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["settings"]["min_withdraw"] = amount
# @BLOODYNIGHTMODMENU code not for sell use own use
    save_data(data)
# @BLOODYNIGHTMODMENU code not for sell use own use
    return True
