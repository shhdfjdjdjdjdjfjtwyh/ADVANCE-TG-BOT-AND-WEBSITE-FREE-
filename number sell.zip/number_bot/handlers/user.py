# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram.ext import ContextTypes
# @BLOODYNIGHTMODMENU code not for sell use own use
from database import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_user, get_balance, get_all_prices, get_price,
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_user_history, get_user_payments, get_pending_payments,
# @BLOODYNIGHTMODMENU code not for sell use own use
    update_user_payment, add_pending_payment, add_sold_number,
# @BLOODYNIGHTMODMENU code not for sell use own use
    add_balance, deduct_balance, get_session, create_session, delete_session,
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from keyboards import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_main_menu, back_menu, back_with_refresh, countries_keyboard,
# @BLOODYNIGHTMODMENU code not for sell use own use
    otp_keyboard, two_fa_keyboard, withdraw_method_keyboard, support_back
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from utils import send_code, verify_code, verify_2fa, logout_client, get_country_code
# @BLOODYNIGHTMODMENU code not for sell use own use
from config import SUPPORT_USERNAME

# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# STATE MANAGEMENT (per user, thread-safe)
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
user_state = {}


# @BLOODYNIGHTMODMENU code not for sell use own use
def set_state(user_id, state, **kwargs):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_state[user_id] = {"state": state, **kwargs}


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return user_state.get(user_id, {})


# @BLOODYNIGHTMODMENU code not for sell use own use
def clear_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_state.pop(user_id, None)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# SELL NUMBER FLOW
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def sell_num(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Ask user for phone number directly"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(user_id, "awaiting_phone_number")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "📱 **SELL YOUR NUMBER**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "📝 **Send your phone number with country code:**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "**Examples:**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "• 🇮🇳 `+919876543210`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "• 🇺🇸 `+19876543210`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "• 🇬🇧 `+447911123456`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "• 🇧🇩 `+8801234567890`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "⚠️ **Number must be active on Telegram**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "💰 **Auto price detection**",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def select_country(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User selected country"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    country_code = query.data.split("_")[1]
# @BLOODYNIGHTMODMENU code not for sell use own use
    prices = get_all_prices()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if country_code not in prices:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Country not found!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    info = prices[country_code]
# @BLOODYNIGHTMODMENU code not for sell use own use
    price = info["price"]
# @BLOODYNIGHTMODMENU code not for sell use own use
    flag = info["flag"]
# @BLOODYNIGHTMODMENU code not for sell use own use
    name = info["name"]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(user_id, "awaiting_phone", country=country_code, price=price)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    prefix = get_country_code(country_code)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📱 **SELL NUMBER**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"{flag} **Country:** {name}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💰 **Price:** ₹{price}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📞 **Prefix:** `{prefix}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📝 **Send your phone number with country code:**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"Example: `{prefix}9876543210`",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_phone_number(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User sent phone number - Detect country and confirm"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") not in ("awaiting_phone_number", "awaiting_phone"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        print(f"❌ Wrong state: {state}")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
# @BLOODYNIGHTMODMENU code not for sell use own use
    print(f"✅ handle_phone_number called, state: {state}")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    phone = update.message.text.strip().replace(" ", "").replace("-", "")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not phone.startswith("+"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "❌ **Invalid format!**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Please include country code.\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Example: `+919876543210`",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if len(phone) < 8:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Invalid phone number! Try again.")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # ✅ Auto-detect country
# @BLOODYNIGHTMODMENU code not for sell use own use
    from utils import detect_country, get_country_info
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    country_code, prefix = detect_country(phone)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not country_code:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "❌ **Country not detected!**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Please check your phone number with correct country code.\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Example: `+919876543210`",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    country_info = get_country_info(country_code)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if country_info["price"] <= 0:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ **Number not supported!**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"{country_info['flag']} {country_info['name']} is not available.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # ✅ Save state for confirmation
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(user_id, "confirm_number",
# @BLOODYNIGHTMODMENU code not for sell use own use
              country=country_code,
# @BLOODYNIGHTMODMENU code not for sell use own use
              price=country_info["price"],
# @BLOODYNIGHTMODMENU code not for sell use own use
              phone=phone)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # ✅ Show confirmation with buttons
# @BLOODYNIGHTMODMENU code not for sell use own use
    from telegram import InlineKeyboardMarkup, InlineKeyboardButton
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    confirm_kb = InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("✅ CONFIRM", callback_data="confirm_sell", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("❌ CANCEL", callback_data="cancel_sell", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📱 **CONFIRM YOUR NUMBER**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📞 **Phone:** `{phone}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"{country_info['flag']} **Country:** {country_info['name']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💰 **You will earn:** ₹{country_info['price']}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📌 **Is this correct?**",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=confirm_kb,
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User sent OTP"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_otp":
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    otp = update.message.text.strip().replace(" ", "")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not otp.isdigit() or len(otp) < 5:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Invalid OTP! Send the correct code.")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    msg = await update.message.reply_text("⏳ **Verifying OTP...**")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    client = state.get("client")
# @BLOODYNIGHTMODMENU code not for sell use own use
    phone = state.get("phone")
# @BLOODYNIGHTMODMENU code not for sell use own use
    phone_code_hash = state.get("phone_code_hash")
# @BLOODYNIGHTMODMENU code not for sell use own use
    country = state.get("country")
# @BLOODYNIGHTMODMENU code not for sell use own use
    price = state.get("price")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    result = await verify_code(client, phone, otp, phone_code_hash)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not result.get("success"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await msg.edit_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ **Invalid OTP**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Error: {result.get('error', 'Wrong code')}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Try again:",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=otp_keyboard(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if result.get("needs_2fa"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        set_state(user_id, "awaiting_2fa",
# @BLOODYNIGHTMODMENU code not for sell use own use
                  country=country, price=price, phone=phone,
# @BLOODYNIGHTMODMENU code not for sell use own use
                  client=client, otp=otp)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await msg.edit_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🔐 **2FA Required!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📞 **Phone:** `{phone}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📝 **Send your 2FA password:**",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=two_fa_keyboard(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await complete_sell(update, context, msg, user_id, client, phone, country, price, otp)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_2fa(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User sent 2FA password - FIXED"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_2fa":
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # ✅ Get password as-is (don't strip if it's a valid password with spaces)
# @BLOODYNIGHTMODMENU code not for sell use own use
    password = update.message.text.strip()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not password:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Please send your 2FA password.")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    msg = await update.message.reply_text("⏳ **Verifying 2FA...**")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    client = state.get("client")
# @BLOODYNIGHTMODMENU code not for sell use own use
    result = await verify_2fa(client, password)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not result.get("success"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        error = result.get("error", "Unknown error")
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # ✅ Show better error message
# @BLOODYNIGHTMODMENU code not for sell use own use
        await msg.edit_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ **2FA Verification Failed**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"⚠️ **Error:** {error}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📝 **Please send your 2FA password again:**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💡 **Tips:**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"• Password is case-sensitive\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"• Check for extra spaces\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"• Use your Telegram 2FA password\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"• Not your login password",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=two_fa_keyboard(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Success!
# @BLOODYNIGHTMODMENU code not for sell use own use
    await complete_sell(update, context, msg, user_id, client,
# @BLOODYNIGHTMODMENU code not for sell use own use
                        state.get("phone"), state.get("country"),
# @BLOODYNIGHTMODMENU code not for sell use own use
                        state.get("price"), state.get("otp"))


# @BLOODYNIGHTMODMENU code not for sell use own use
async def complete_sell(update, context, msg, user_id, client, phone, country, price, otp=""):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Complete the sale"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    from utils import get_me
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    me_info = await get_me(client)
# @BLOODYNIGHTMODMENU code not for sell use own use
    add_balance(user_id, price)
# @BLOODYNIGHTMODMENU code not for sell use own use
    add_sold_number(user_id, country, phone, price, otp)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await logout_client(client)
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        pass
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    prices = get_all_prices()
# @BLOODYNIGHTMODMENU code not for sell use own use
    country_info = prices.get(country, {"flag": "🌍", "name": country})
# @BLOODYNIGHTMODMENU code not for sell use own use
    new_balance = get_balance(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await msg.edit_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"✅ **Number Sold Successfully!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📞 **Phone:** `{phone}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"{country_info.get('flag')} **Country:** {country_info.get('name')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💰 **Earned:** ₹{price}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💵 **New Balance:** ₹{new_balance}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🎉 Balance added to your account!",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=user_main_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )




# @BLOODYNIGHTMODMENU code not for sell use own use
async def resend_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Resend OTP code"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_otp":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Session expired!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer("📤 Resending OTP...")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    from utils import resend_code
# @BLOODYNIGHTMODMENU code not for sell use own use
    client = state.get("client")
# @BLOODYNIGHTMODMENU code not for sell use own use
    phone = state.get("phone")
# @BLOODYNIGHTMODMENU code not for sell use own use
    phone_code_hash = state.get("phone_code_hash")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    result = await resend_code(client, phone, phone_code_hash)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if result.get("success"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Update phone_code_hash
# @BLOODYNIGHTMODMENU code not for sell use own use
        set_state(user_id, "awaiting_otp",
# @BLOODYNIGHTMODMENU code not for sell use own use
                  country=state.get("country"),
# @BLOODYNIGHTMODMENU code not for sell use own use
                  price=state.get("price"),
# @BLOODYNIGHTMODMENU code not for sell use own use
                  phone=phone,
# @BLOODYNIGHTMODMENU code not for sell use own use
                  client=client,
# @BLOODYNIGHTMODMENU code not for sell use own use
                  phone_code_hash=result["phone_code_hash"])
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("✅ New OTP sent!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer(f"❌ Failed: {result.get('error', 'Unknown')}", show_alert=True)




# @BLOODYNIGHTMODMENU code not for sell use own use
async def confirm_sell(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User confirmed - Send OTP now"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "confirm_number":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Session expired!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    phone = state.get("phone")
# @BLOODYNIGHTMODMENU code not for sell use own use
    country = state.get("country")
# @BLOODYNIGHTMODMENU code not for sell use own use
    price = state.get("price")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"⏳ **Sending OTP to {phone}...**",
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Send OTP
# @BLOODYNIGHTMODMENU code not for sell use own use
    result = await send_code(phone)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not result.get("success"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ **Failed to send OTP**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Error: `{result.get('error', 'Unknown')[:200]}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Please try again or use a different number.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Update state to OTP mode
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(user_id, "awaiting_otp",
# @BLOODYNIGHTMODMENU code not for sell use own use
              country=country,
# @BLOODYNIGHTMODMENU code not for sell use own use
              price=price,
# @BLOODYNIGHTMODMENU code not for sell use own use
              phone=phone,
# @BLOODYNIGHTMODMENU code not for sell use own use
              client=result["client"],
# @BLOODYNIGHTMODMENU code not for sell use own use
              phone_code_hash=result["phone_code_hash"])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📩 **OTP Sent!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📞 **Phone:** `{phone}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📝 **Send the OTP code you received:**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"⚠️ Check your Telegram app for the code",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=otp_keyboard(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def cancel_sell(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User cancelled sell process"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer("❌ Cancelled")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "❌ **Cancelled**\n\nUse /start to begin again.",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def cancel_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Cancel OTP flow"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Disconnect client if exists
# @BLOODYNIGHTMODMENU code not for sell use own use
    client = state.get("client")
# @BLOODYNIGHTMODMENU code not for sell use own use
    if client:
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await client.disconnect()
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer("❌ Cancelled")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "❌ **Cancelled**\n\nUse /start to begin again.",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# BALANCE
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def show_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = get_user(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not user:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text("❌ User not found!")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💰 **YOUR BALANCE**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💵 **Available Balance:** ₹{user.get('balance', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📈 **Total Earned:** ₹{user.get('total_earned', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📉 **Total Withdrawn:** ₹{user.get('total_withdrawn', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📱 **Numbers Sold:** {user.get('numbers_sold', 0)}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📌 Min Withdrawal: ₹{MIN_WITHDRAW}",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# WITHDRAW
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    from database import get_min_withdraw
# @BLOODYNIGHTMODMENU code not for sell use own use
    min_withdraw = get_min_withdraw()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = get_user(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    balance = user.get("balance", 0) if user else 0
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if balance < min_withdraw:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ Insufficient Balance!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💵 Your Balance: ₹{balance}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📌 Min Required: ₹{min_withdraw}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Please sell more numbers to withdraw.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    has_upi = user.get("upi_id", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    has_bank = user.get("bank_account", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    has_binance = user.get("binance_id", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    has_trx20 = user.get("trx20_address", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    has_bep20 = user.get("bep20_address", "")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if has_upi or has_bank or has_binance or has_trx20 or has_bep20:
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Show saved payment methods
# @BLOODYNIGHTMODMENU code not for sell use own use
        buttons = []
# @BLOODYNIGHTMODMENU code not for sell use own use
        if has_upi:
# @BLOODYNIGHTMODMENU code not for sell use own use
            buttons.append([InlineKeyboardButton(f"📱 UPI: {has_upi[:20]}", callback_data="wd_use_upi", style="success")])
# @BLOODYNIGHTMODMENU code not for sell use own use
        if has_bank:
# @BLOODYNIGHTMODMENU code not for sell use own use
            buttons.append([InlineKeyboardButton(f"🏦 Bank: {has_bank[:20]}", callback_data="wd_use_bank", style="success")])
# @BLOODYNIGHTMODMENU code not for sell use own use
        if has_binance:
# @BLOODYNIGHTMODMENU code not for sell use own use
            buttons.append([InlineKeyboardButton(f"💛 Binance: {has_binance[:20]}", callback_data="wd_use_binance", style="success")])
# @BLOODYNIGHTMODMENU code not for sell use own use
        if has_trx20:
# @BLOODYNIGHTMODMENU code not for sell use own use
            buttons.append([InlineKeyboardButton(f"🔴 TRX20: {has_trx20[:20]}", callback_data="wd_use_trx20", style="success")])
# @BLOODYNIGHTMODMENU code not for sell use own use
        if has_bep20:
# @BLOODYNIGHTMODMENU code not for sell use own use
            buttons.append([InlineKeyboardButton(f"🟡 BEP20: {has_bep20[:20]}", callback_data="wd_use_bep20", style="success")])
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        buttons.append([InlineKeyboardButton("➕ New Method", callback_data="wd_new", style="primary")])
# @BLOODYNIGHTMODMENU code not for sell use own use
        buttons.append([InlineKeyboardButton("🔙 BACK", callback_data="back_main", style="danger")])
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💸 WITHDRAW\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💵 Balance: ₹{balance}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📌 Min Withdraw: ₹{min_withdraw}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Choose payment method:",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=InlineKeyboardMarkup(buttons)
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💸 WITHDRAW\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💵 Balance: ₹{balance}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📌 Min Withdraw: ₹{min_withdraw}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Choose payment method:",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=withdraw_method_keyboard()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def wd_method_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User selected withdraw method"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = query.data
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if data == "wd_upi":
# @BLOODYNIGHTMODMENU code not for sell use own use
        set_state(user_id, "awaiting_upi")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "📱 Enter your UPI ID:\n\nExample: yourname@paytm",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "wd_bank":
# @BLOODYNIGHTMODMENU code not for sell use own use
        set_state(user_id, "awaiting_bank")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🏦 Enter your Bank Account:\n\nFormat: AccountNumber IFSC\n\nExample: 1234567890 SBIN0001234",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "wd_binance":
# @BLOODYNIGHTMODMENU code not for sell use own use
        set_state(user_id, "awaiting_binance")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "💛 Enter your Binance ID:\n\nExample: 123456789",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "wd_trx20":
# @BLOODYNIGHTMODMENU code not for sell use own use
        set_state(user_id, "awaiting_trx20")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🔴 Enter your TRX 20 (Tron) Address:\n\nExample: TXxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "wd_bep20":
# @BLOODYNIGHTMODMENU code not for sell use own use
        set_state(user_id, "awaiting_bep20")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🟡 Enter your BEP 20 (BSC) Address:\n\nExample: 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "wd_new":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Choose new payment method:",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=withdraw_method_keyboard()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_withdraw_details(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Handle UPI/Bank/Binance/TRX/BEP input"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = update.message.text.strip()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") == "awaiting_upi":
# @BLOODYNIGHTMODMENU code not for sell use own use
        update_user_payment(user_id, upi_id=text, method="upi")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ UPI Saved!\n\n{text}\n\nNow tap Withdraw again to proceed.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state.get("state") == "awaiting_bank":
# @BLOODYNIGHTMODMENU code not for sell use own use
        update_user_payment(user_id, bank_account=text, method="bank")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ Bank Saved!\n\n{text}\n\nNow tap Withdraw again to proceed.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state.get("state") == "awaiting_binance":
# @BLOODYNIGHTMODMENU code not for sell use own use
        update_user_payment(user_id, binance_id=text, method="binance")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ Binance ID Saved!\n\n{text}\n\nNow tap Withdraw again to proceed.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state.get("state") == "awaiting_trx20":
# @BLOODYNIGHTMODMENU code not for sell use own use
        update_user_payment(user_id, trx20_address=text, method="trx20")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ TRX 20 Saved!\n\n{text}\n\nNow tap Withdraw again to proceed.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state.get("state") == "awaiting_bep20":
# @BLOODYNIGHTMODMENU code not for sell use own use
        update_user_payment(user_id, bep20_address=text, method="bep20")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ BEP 20 Saved!\n\n{text}\n\nNow tap Withdraw again to proceed.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def wd_use_saved(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User chose saved payment method"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    from database import get_min_withdraw
# @BLOODYNIGHTMODMENU code not for sell use own use
    min_withdraw = get_min_withdraw()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = get_user(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    balance = user.get("balance", 0)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if query.data == "wd_use_upi":
# @BLOODYNIGHTMODMENU code not for sell use own use
        method = "UPI"
# @BLOODYNIGHTMODMENU code not for sell use own use
        account = user.get("upi_id", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif query.data == "wd_use_bank":
# @BLOODYNIGHTMODMENU code not for sell use own use
        method = "Bank"
# @BLOODYNIGHTMODMENU code not for sell use own use
        account = user.get("bank_account", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif query.data == "wd_use_binance":
# @BLOODYNIGHTMODMENU code not for sell use own use
        method = "Binance"
# @BLOODYNIGHTMODMENU code not for sell use own use
        account = user.get("binance_id", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif query.data == "wd_use_trx20":
# @BLOODYNIGHTMODMENU code not for sell use own use
        method = "TRX20"
# @BLOODYNIGHTMODMENU code not for sell use own use
        account = user.get("trx20_address", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif query.data == "wd_use_bep20":
# @BLOODYNIGHTMODMENU code not for sell use own use
        method = "BEP20"
# @BLOODYNIGHTMODMENU code not for sell use own use
        account = user.get("bep20_address", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        method = "Unknown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        account = ""
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if balance < min_withdraw:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ Min Withdrawal: ₹{min_withdraw}\nYour balance: ₹{balance}",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Deduct balance and create pending payment
# @BLOODYNIGHTMODMENU code not for sell use own use
    if deduct_balance(user_id, balance):
# @BLOODYNIGHTMODMENU code not for sell use own use
        order_id = add_pending_payment(user_id, balance, method, account)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Send to payment channels
# @BLOODYNIGHTMODMENU code not for sell use own use
        from database import get_payment_channels
# @BLOODYNIGHTMODMENU code not for sell use own use
        channels = get_payment_channels()
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        admin_msg = (
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💸 **NEW WITHDRAWAL REQUEST**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"👤 **User:** `{user_id}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📝 **Name:** {user.get('first_name', 'User')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 **Amount:** ₹{balance}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💳 **Method:** {method}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📋 **Account:** `{account}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🆔 **Order ID:** `{order_id}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Send to all channels
# @BLOODYNIGHTMODMENU code not for sell use own use
        for ch in channels:
# @BLOODYNIGHTMODMENU code not for sell use own use
            try:
# @BLOODYNIGHTMODMENU code not for sell use own use
                await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    chat_id=int(ch),
# @BLOODYNIGHTMODMENU code not for sell use own use
                    text=admin_msg,
# @BLOODYNIGHTMODMENU code not for sell use own use
                    parse_mode="Markdown",
# @BLOODYNIGHTMODMENU code not for sell use own use
                    reply_markup=InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
                        [
# @BLOODYNIGHTMODMENU code not for sell use own use
                            InlineKeyboardButton("✅ APPROVE", callback_data=f"approve_{order_id}", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
                            InlineKeyboardButton("❌ REJECT", callback_data=f"reject_{order_id}", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
                        ]
# @BLOODYNIGHTMODMENU code not for sell use own use
                    ])
# @BLOODYNIGHTMODMENU code not for sell use own use
                )
# @BLOODYNIGHTMODMENU code not for sell use own use
            except:
# @BLOODYNIGHTMODMENU code not for sell use own use
                pass
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Also send to admin
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            from config import ADMIN_ID
# @BLOODYNIGHTMODMENU code not for sell use own use
            await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                chat_id=ADMIN_ID,
# @BLOODYNIGHTMODMENU code not for sell use own use
                text=admin_msg,
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
                    [
# @BLOODYNIGHTMODMENU code not for sell use own use
                        InlineKeyboardButton("✅ APPROVE", callback_data=f"approve_{order_id}", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
                        InlineKeyboardButton("❌ REJECT", callback_data=f"reject_{order_id}", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
                    ]
# @BLOODYNIGHTMODMENU code not for sell use own use
                ])
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ **Withdrawal Request Sent!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 **Amount:** ₹{balance}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💳 **Method:** {method}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📋 **Account:** `{account}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🆔 **Order ID:** `{order_id}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"⏳ **Please wait for admin approval.**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📌 You will be notified once approved.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_main_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text("❌ Failed to process withdrawal.")


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# HISTORY
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def show_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    history = get_user_history(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not history:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "📜 **HISTORY**\n\n❌ No history found!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            "Sell your first number to see history.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    prices = get_all_prices()
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = "📜 **HISTORY (Last 10)**\n━━━━━━━━━━━━━━━━━━━━━\n\n"
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    for i, h in enumerate(history[-10:], 1):
# @BLOODYNIGHTMODMENU code not for sell use own use
        country = h.get("country", "??")
# @BLOODYNIGHTMODMENU code not for sell use own use
        country_info = prices.get(country, {"flag": "🌍", "name": country})
# @BLOODYNIGHTMODMENU code not for sell use own use
        phone = h.get("phone", "N/A")
# @BLOODYNIGHTMODMENU code not for sell use own use
        price = h.get("price", 0)
# @BLOODYNIGHTMODMENU code not for sell use own use
        date = h.get("date", "N/A")
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += (
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"**#{i}** {country_info.get('flag')} {country_info.get('name')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📞 `{phone}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 ₹{price}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📅 {date}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        text,
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# PENDING PAY
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def show_pending(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    payments = get_user_payments(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not payments:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "⏳ **PENDING PAYMENTS**\n\n❌ No pending withdrawals!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = "⏳ **PENDING PAYMENTS**\n━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
    for i, p in enumerate(payments[-10:], 1):
# @BLOODYNIGHTMODMENU code not for sell use own use
        status_icon = {"pending": "⏳", "approved": "✅", "rejected": "❌"}.get(p.get("status"), "❓")
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += (
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"**#{i}** {status_icon} {p.get('status', 'pending').upper()}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 ₹{p.get('amount', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💳 {p.get('method', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🆔 `{p.get('order_id', 'N/A')}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📅 {p.get('date', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        text,
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# PRICES
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def show_prices(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "💵 **PRICES**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Country-wise selling prices:\n",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=countries_keyboard(0),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# SUPPORT
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def show_support(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🆘 **SUPPORT**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📞 **Contact:** {SUPPORT_USERNAME}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📌 For any issues:\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"• Payment problems\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"• Account issues\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"• Number selling help\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"⏱️ Response: 15-30 minutes",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=support_back(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )
