# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram.ext import ContextTypes
# @BLOODYNIGHTMODMENU code not for sell use own use
from config import ADMIN_ID, SUPPORT_USERNAME
# @BLOODYNIGHTMODMENU code not for sell use own use
from database import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_all_users, get_user, ban_user, unban_user, is_banned,
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_payment_channels, add_payment_channel, remove_payment_channel,
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_all_prices, set_price, get_stats, get_pending_payments,
# @BLOODYNIGHTMODMENU code not for sell use own use
    approve_payment, reject_payment, add_balance,
# @BLOODYNIGHTMODMENU code not for sell use own use
    load_data, save_data
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from keyboards import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_main_menu, users_list_keyboard, user_detail_keyboard,
# @BLOODYNIGHTMODMENU code not for sell use own use
    channels_list_keyboard, prices_admin_keyboard, pending_payment_keyboard,
# @BLOODYNIGHTMODMENU code not for sell use own use
    back_menu
# @BLOODYNIGHTMODMENU code not for sell use own use
)

# @BLOODYNIGHTMODMENU code not for sell use own use
# Admin state
# @BLOODYNIGHTMODMENU code not for sell use own use
admin_state = {}


# @BLOODYNIGHTMODMENU code not for sell use own use
def is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return user_id == ADMIN_ID


# @BLOODYNIGHTMODMENU code not for sell use own use
def set_state(user_id, state, **kwargs):
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_state[user_id] = {"state": state, **kwargs}


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return admin_state.get(user_id, {})


# @BLOODYNIGHTMODMENU code not for sell use own use
def clear_state(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_state.pop(user_id, None)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# ADMIN PANEL MAIN
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Admin only!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "🔐 **ADMIN PANEL**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Choose an option:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=admin_main_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# STATS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    stats = get_stats()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📊 **STATS**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👥 Total Users: {stats['total_users']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📱 Numbers Sold: {stats['total_sold']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💰 Total Earned: ₹{stats['total_earned']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"⏳ Pending Withdrawals: {stats['pending_withdrawals']}",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# VIEW USERS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def view_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    users = get_all_users()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not users:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "👥 **USERS**\n\n❌ No users found!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👥 **USERS** ({len(users)})\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"Tap a user to view details:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=users_list_keyboard(users, 0),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def user_page(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    page = int(query.data.split("_")[2])
# @BLOODYNIGHTMODMENU code not for sell use own use
    users = get_all_users()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👥 **USERS** ({len(users)})\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"Page {page + 1}",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=users_list_keyboard(users, page),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def view_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = query.data.split("_")[1]
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = get_user(user_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not user:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text("❌ User not found!")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    status = "🚫 BANNED" if user.get("banned") else "✅ ACTIVE"
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👤 **USER DETAILS**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🆔 **ID:** `{user_id}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"👤 **Name:** {user.get('first_name', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📝 **Username:** @{user.get('username', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💰 **Balance:** ₹{user.get('balance', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📈 **Total Earned:** ₹{user.get('total_earned', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📉 **Total Withdrawn:** ₹{user.get('total_withdrawn', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📱 **Numbers Sold:** {user.get('numbers_sold', 0)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📅 **Joined:** {user.get('joined', 'N/A')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🚦 **Status:** {status}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💳 **UPI:** `{user.get('upi_id', 'Not set')}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"🏦 **Bank:** `{user.get('bank_account', 'Not set')}`",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=user_detail_keyboard(user_id, user.get("banned", False)),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# BAN / UNBAN
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def ban_user_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = query.data.split("_")[1]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if ban_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("🚫 User banned!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        await view_user(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Failed to ban", show_alert=True)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def unban_user_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = query.data.split("_")[1]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if unban_user(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("✅ User unbanned!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        await view_user(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Failed to unban", show_alert=True)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def ban_user_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_ban_id")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "🚫 **BAN USER**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Send user ID to ban:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def unban_user_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_unban_id")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "✅ **UNBAN USER**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Send user ID to unban:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_ban_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    state_name = state.get("state")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state_name not in ("awaiting_ban_id", "awaiting_unban_id"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    target_id = update.message.text.strip()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state_name == "awaiting_ban_id":
# @BLOODYNIGHTMODMENU code not for sell use own use
        if ban_user(target_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text(f"✅ User `{target_id}` banned!", parse_mode="Markdown")
# @BLOODYNIGHTMODMENU code not for sell use own use
        else:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text("❌ User not found!")
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        if unban_user(target_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text(f"✅ User `{target_id}` unbanned!", parse_mode="Markdown")
# @BLOODYNIGHTMODMENU code not for sell use own use
        else:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await update.message.reply_text("❌ User not found!")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# PAYMENT CHANNELS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def add_channel_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_channel_id")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "➕ **ADD PAYMENT CHANNEL**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Send channel ID:\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Example: `-1001234567890`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "⚠️ Make sure bot is admin in channel!",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def view_channels(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    channels = get_payment_channels()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not channels:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "📢 **PAYMENT CHANNELS**\n\n❌ No channels added!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
                [InlineKeyboardButton("➕ ADD CHANNEL", callback_data="add_channel", style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
                [InlineKeyboardButton("🔙 BACK", callback_data="admin_panel", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
            ]),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = f"📢 **PAYMENT CHANNELS** ({len(channels)})\n━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
    for i, ch in enumerate(channels, 1):
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += f"{i}. `{ch}`\n"
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        text,
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=channels_list_keyboard(channels),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def del_channel(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    channel_id = query.data.replace("delchannel_", "")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if remove_payment_channel(channel_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("✅ Channel removed!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        await view_channels(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("❌ Failed to remove", show_alert=True)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_channel_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_channel_id":
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    channel_id = update.message.text.strip()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if add_payment_channel(channel_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(f"✅ Channel `{channel_id}` added!", parse_mode="Markdown")
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Channel already exists!")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# SET SUPPORT
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def set_support(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_support")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "🆘 **SET SUPPORT USERNAME**\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Send new support username:\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Example: `@YourSupport`",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_support_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_support":
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    username = update.message.text.strip()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    data["settings"]["support_username"] = username
# @BLOODYNIGHTMODMENU code not for sell use own use
    save_data(data)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(f"✅ Support set to: {username}")
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# SET PRICES
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def set_prices(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "💵 **SET PRICES**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "Tap a country to edit its price:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=prices_admin_keyboard(0),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def adminprice_page(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    page = int(query.data.split("_")[2])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        "💵 **SET PRICES**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        "━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"Page {page + 1}",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=prices_admin_keyboard(page),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def edit_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    country_code = query.data.split("_")[1]
# @BLOODYNIGHTMODMENU code not for sell use own use
    prices = get_all_prices()
# @BLOODYNIGHTMODMENU code not for sell use own use
    info = prices.get(country_code, {})
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_price", country=country_code)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💵 **EDIT PRICE**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"{info.get('flag', '🌍')} **Country:** {info.get('name', country_code)}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💰 **Current Price:** ₹{info.get('price', 0)}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📝 Send new price:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_price_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_price":
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        new_price = int(update.message.text.strip())
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Invalid price! Send a number.")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    country = state.get("country")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if set_price(country, new_price):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(f"✅ Price updated to ₹{new_price}")
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Failed to update")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# PENDING WITHDRAWALS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def admin_pending(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    pending = get_pending_payments()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not pending:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "⏳ **PENDING WITHDRAWALS**\n\n✅ No pending requests!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Send each pending separately with buttons
# @BLOODYNIGHTMODMENU code not for sell use own use
    for p in pending[:5]:
# @BLOODYNIGHTMODMENU code not for sell use own use
        text = (
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💸 **WITHDRAWAL REQUEST**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"👤 **User:** `{p['user_id']}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 **Amount:** ₹{p['amount']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💳 **Method:** {p['method']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📋 **Account:** `{p['account']}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🆔 **Order ID:** `{p['order_id']}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📅 **Date:** {p['date']}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                chat_id=update.effective_user.id,
# @BLOODYNIGHTMODMENU code not for sell use own use
                text=text,
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=pending_payment_keyboard(p["order_id"])
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"⏳ **{len(pending)} pending withdrawals** sent above.",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def approve_withdrawal(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    order_id = query.data.replace("approve_", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    payment = approve_payment(order_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if payment:
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Notify user
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                chat_id=int(payment["user_id"]),
# @BLOODYNIGHTMODMENU code not for sell use own use
                text=(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"✅ **Withdrawal Approved!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"💰 **Amount:** ₹{payment['amount']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"💳 **Method:** {payment['method']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"📋 **Account:** `{payment['account']}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"🆔 **Order ID:** `{order_id}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"📌 Your payment has been processed.\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"Please check your {payment['method']} account."
# @BLOODYNIGHTMODMENU code not for sell use own use
                ),
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"✅ **APPROVED**\n\nOrder `{order_id}` processed!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text("❌ Payment not found!")


# @BLOODYNIGHTMODMENU code not for sell use own use
async def reject_withdrawal(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    order_id = query.data.replace("reject_", "")
# @BLOODYNIGHTMODMENU code not for sell use own use
    payment = reject_payment(order_id)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if payment:
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Refund balance
# @BLOODYNIGHTMODMENU code not for sell use own use
        add_balance(payment["user_id"], payment["amount"])
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Notify user
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await context.bot.send_message(
# @BLOODYNIGHTMODMENU code not for sell use own use
                chat_id=int(payment["user_id"]),
# @BLOODYNIGHTMODMENU code not for sell use own use
                text=(
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"❌ **Withdrawal Rejected!**\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"💰 **Amount:** ₹{payment['amount']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"🆔 **Order ID:** `{order_id}`\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"📌 Reason: {payment.get('reason', 'Rejected by admin')}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                    f"💰 Balance refunded to your account."
# @BLOODYNIGHTMODMENU code not for sell use own use
                ),
# @BLOODYNIGHTMODMENU code not for sell use own use
                parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"❌ **REJECTED**\n\nOrder `{order_id}` rejected. Balance refunded.",
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text("❌ Payment not found!")


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# ALL HISTORY
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def all_history(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = load_data()
# @BLOODYNIGHTMODMENU code not for sell use own use
    numbers = data.get("numbers_sold", [])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not numbers:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "📜 **ALL HISTORY**\n\n❌ No history found!",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
            parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    text = f"📜 **ALL HISTORY** (Last 15)\n━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
    for i, n in enumerate(numbers[-15:], 1):
# @BLOODYNIGHTMODMENU code not for sell use own use
        text += (
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"**#{i}** User: `{n['user_id']}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📞 `{n['phone']}`\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 ₹{n['price']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📅 {n['date']}\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"━━━━━━━━━━━━━━━━━━━━━\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        text,
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu(),
# @BLOODYNIGHTMODMENU code not for sell use own use
        parse_mode="Markdown"
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# MIN WITHDRAW SETTINGS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def set_min_withdraw_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Admin - set min withdraw menu"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.answer()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(update.effective_user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    from database import get_min_withdraw
# @BLOODYNIGHTMODMENU code not for sell use own use
    current = get_min_withdraw()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_state(update.effective_user.id, "awaiting_min_withdraw")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"💸 SET MIN WITHDRAW\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"━━━━━━━━━━━━━━━━━━━━━\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"Current: ₹{current}\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
        f"📝 Send new minimum withdrawal amount:",
# @BLOODYNIGHTMODMENU code not for sell use own use
        reply_markup=back_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
    )


# @BLOODYNIGHTMODMENU code not for sell use own use
async def handle_min_withdraw_input(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Admin - handle min withdraw input"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state.get("state") != "awaiting_min_withdraw":
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        amount = int(update.message.text.strip())
# @BLOODYNIGHTMODMENU code not for sell use own use
        if amount <= 0:
# @BLOODYNIGHTMODMENU code not for sell use own use
            raise ValueError("Must be positive")
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("❌ Invalid amount! Send a positive number.")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    from database import set_min_withdraw
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_min_withdraw(amount)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await update.message.reply_text(f"✅ Min withdraw set to ₹{amount}")
# @BLOODYNIGHTMODMENU code not for sell use own use
    clear_state(user_id)
