# @BLOODYNIGHTMODMENU code not for sell use own use
#!/usr/bin/env python3
# @BLOODYNIGHTMODMENU code not for sell use own use
import asyncio
# @BLOODYNIGHTMODMENU code not for sell use own use
import logging
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes

# @BLOODYNIGHTMODMENU code not for sell use own use
from config import BOT_TOKEN, ADMIN_ID
# @BLOODYNIGHTMODMENU code not for sell use own use
from database import add_user, get_user, is_banned, init_db
# @BLOODYNIGHTMODMENU code not for sell use own use
from keyboards import user_main_menu, admin_main_menu, back_menu

# @BLOODYNIGHTMODMENU code not for sell use own use
# Import handlers
# @BLOODYNIGHTMODMENU code not for sell use own use
from handlers.user import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    sell_num, select_country, handle_phone_number, handle_otp, handle_2fa,
# @BLOODYNIGHTMODMENU code not for sell use own use
    complete_sell, cancel_otp, resend_otp, confirm_sell, cancel_sell,
# @BLOODYNIGHTMODMENU code not for sell use own use
    show_balance, withdraw, wd_method_selected, handle_withdraw_details,
# @BLOODYNIGHTMODMENU code not for sell use own use
    wd_use_saved, show_history, show_pending, show_prices, show_support,
# @BLOODYNIGHTMODMENU code not for sell use own use
    get_state as user_get_state, user_state
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from handlers.admin import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_panel, admin_stats, view_users, user_page, view_user,
# @BLOODYNIGHTMODMENU code not for sell use own use
    ban_user_action, unban_user_action, ban_user_menu, unban_user_menu,
# @BLOODYNIGHTMODMENU code not for sell use own use
    handle_ban_input, add_channel_menu, view_channels, del_channel,
# @BLOODYNIGHTMODMENU code not for sell use own use
    handle_channel_input, set_support, handle_support_input,
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_prices, adminprice_page, edit_price, handle_price_input,
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_pending, approve_withdrawal, reject_withdrawal, all_history,
# @BLOODYNIGHTMODMENU code not for sell use own use
    set_min_withdraw_menu, handle_min_withdraw_input,
# @BLOODYNIGHTMODMENU code not for sell use own use
    is_admin, get_state as admin_get_state
# @BLOODYNIGHTMODMENU code not for sell use own use
)

# @BLOODYNIGHTMODMENU code not for sell use own use
logging.basicConfig(
# @BLOODYNIGHTMODMENU code not for sell use own use
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
# @BLOODYNIGHTMODMENU code not for sell use own use
    level=logging.INFO
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
logger = logging.getLogger(__name__)

# @BLOODYNIGHTMODMENU code not for sell use own use
init_db()


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# START COMMAND
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user = update.effective_user
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Check banned (except admin)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_banned(user.id) and not is_admin(user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "🚫 You are banned!\n\nContact support for help."
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Add user
# @BLOODYNIGHTMODMENU code not for sell use own use
    add_user(user.id, user.username, user.first_name)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_admin(user.id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        # Admin - User panel + Admin button
# @BLOODYNIGHTMODMENU code not for sell use own use
        kb_rows = list(user_main_menu().inline_keyboard)
# @BLOODYNIGHTMODMENU code not for sell use own use
        kb_rows.append([
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🔐 ADMIN PANEL", callback_data="admin_panel", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ])
# @BLOODYNIGHTMODMENU code not for sell use own use
        user_kb = InlineKeyboardMarkup(kb_rows)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"👋 Welcome Admin {user.first_name}!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📱 Number Sell Bot\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 Sell your Telegram accounts\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💵 Earn money instantly\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🏦 Withdraw to UPI/Bank\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🔐 You have ADMIN access\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Tap ADMIN PANEL button below 👇",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_kb
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"👋 Welcome {user.first_name}!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"📱 Number Sell Bot\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💰 Sell your Telegram accounts\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💵 Earn money instantly\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"🏦 Withdraw to UPI/Bank\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"Choose an option below:",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=user_main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
        )


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# CALLBACK ROUTER
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    query = update.callback_query
# @BLOODYNIGHTMODMENU code not for sell use own use
    data = query.data
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Check banned (except for admin)
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_banned(user_id) and not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("🚫 You are banned!", show_alert=True)
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Back to main
# @BLOODYNIGHTMODMENU code not for sell use own use
    if data == "back_main":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer()
# @BLOODYNIGHTMODMENU code not for sell use own use
        user = get_user(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
        name = user.get("first_name", "User") if user else "User"
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        if is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
            kb_rows = list(user_main_menu().inline_keyboard)
# @BLOODYNIGHTMODMENU code not for sell use own use
            kb_rows.append([
# @BLOODYNIGHTMODMENU code not for sell use own use
                InlineKeyboardButton("🔐 ADMIN PANEL", callback_data="admin_panel", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
            ])
# @BLOODYNIGHTMODMENU code not for sell use own use
            user_kb = InlineKeyboardMarkup(kb_rows)
# @BLOODYNIGHTMODMENU code not for sell use own use
            await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👋 Welcome Admin {name}!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"🔐 Admin access available\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"Tap ADMIN PANEL below 👇",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=user_kb
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
        else:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"👋 Welcome {name}!\n\n"
# @BLOODYNIGHTMODMENU code not for sell use own use
                f"Choose an option below:",
# @BLOODYNIGHTMODMENU code not for sell use own use
                reply_markup=user_main_menu()
# @BLOODYNIGHTMODMENU code not for sell use own use
            )
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # ===== USER SIDE =====
# @BLOODYNIGHTMODMENU code not for sell use own use
    if data == "sell_num":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await sell_num(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("sell_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await select_country(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("price_page_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        page = int(data.split("_")[2])
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer()
# @BLOODYNIGHTMODMENU code not for sell use own use
        from keyboards import countries_keyboard
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.edit_message_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            f"💵 PRICES\n━━━━━━━━━━━━━━━━━━━━━\n\nPage {page + 1}",
# @BLOODYNIGHTMODMENU code not for sell use own use
            reply_markup=countries_keyboard(page)
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "balance":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await show_balance(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "withdraw":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await withdraw(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data in ("wd_upi", "wd_bank", "wd_binance", "wd_trx20", "wd_bep20", "wd_new"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await wd_method_selected(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data in ("wd_use_upi", "wd_use_bank", "wd_use_binance", "wd_use_trx20", "wd_use_bep20"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await wd_use_saved(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "history":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await show_history(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "pending_pay":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await show_pending(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "prices":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await show_prices(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "support":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await show_support(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "cancel_otp":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await cancel_otp(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "resend_otp":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await resend_otp(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "confirm_sell":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await confirm_sell(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "cancel_sell":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await cancel_sell(update, context)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # ===== ADMIN SIDE =====
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "admin_panel":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await admin_panel(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "admin_stats":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await admin_stats(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "view_users":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await view_users(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("user_page_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await user_page(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("viewuser_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await view_user(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("ban_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await ban_user_action(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("unban_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await unban_user_action(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "ban_user_menu":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await ban_user_menu(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "unban_user_menu":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await unban_user_menu(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "add_channel":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await add_channel_menu(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "view_channels":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await view_channels(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("delchannel_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await del_channel(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "set_support":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await set_support(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "set_prices":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await set_prices(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("adminprice_page_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await adminprice_page(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("editprice_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await edit_price(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "admin_pending":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await admin_pending(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("approve_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await approve_withdrawal(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data.startswith("reject_"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await reject_withdrawal(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "all_history":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await all_history(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "set_min_withdraw":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await set_min_withdraw_menu(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif data == "noop":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer()
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await query.answer("⚠️ Coming soon!")


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# MESSAGE HANDLER
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_id = update.effective_user.id
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Check banned
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_banned(user_id) and not is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("🚫 You are banned!")
# @BLOODYNIGHTMODMENU code not for sell use own use
        return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Get state
# @BLOODYNIGHTMODMENU code not for sell use own use
    user_state_data = user_get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    admin_state_data = admin_get_state(user_id)
# @BLOODYNIGHTMODMENU code not for sell use own use
    state = admin_state_data.get("state") or user_state_data.get("state")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    logger.info(f"User {user_id} state: {state}")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Admin states
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_admin(user_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
        if state in ("awaiting_ban_id", "awaiting_unban_id"):
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_ban_input(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
# @BLOODYNIGHTMODMENU code not for sell use own use
        elif state == "awaiting_channel_id":
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_channel_input(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
# @BLOODYNIGHTMODMENU code not for sell use own use
        elif state == "awaiting_support":
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_support_input(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
# @BLOODYNIGHTMODMENU code not for sell use own use
        elif state == "awaiting_price":
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_price_input(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
# @BLOODYNIGHTMODMENU code not for sell use own use
        elif state == "awaiting_min_withdraw":
# @BLOODYNIGHTMODMENU code not for sell use own use
            await handle_min_withdraw_input(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
            return
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # User states
# @BLOODYNIGHTMODMENU code not for sell use own use
    if state in ("awaiting_phone_number", "awaiting_phone"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await handle_phone_number(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state == "confirm_number":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text(
# @BLOODYNIGHTMODMENU code not for sell use own use
            "📱 Please click CONFIRM or CANCEL button above ⬆️"
# @BLOODYNIGHTMODMENU code not for sell use own use
        )
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state == "awaiting_otp":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await handle_otp(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state == "awaiting_2fa":
# @BLOODYNIGHTMODMENU code not for sell use own use
        await handle_2fa(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    elif state in ("awaiting_upi", "awaiting_bank", "awaiting_binance", "awaiting_trx20", "awaiting_bep20"):
# @BLOODYNIGHTMODMENU code not for sell use own use
        await handle_withdraw_details(update, context)
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await update.message.reply_text("Use /start to open menu.")


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# MAIN
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
async def main():
# @BLOODYNIGHTMODMENU code not for sell use own use
    application = Application.builder().token(BOT_TOKEN).build()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    application.add_handler(CommandHandler("start", start))
# @BLOODYNIGHTMODMENU code not for sell use own use
    application.add_handler(CallbackQueryHandler(callback_router))
# @BLOODYNIGHTMODMENU code not for sell use own use
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("🤖 NUMBER SELL BOT RUNNING")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("✅ Multi-user support")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("✅ Thread-safe")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("✅ Colored buttons")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("✅ Telethon OTP system")
# @BLOODYNIGHTMODMENU code not for sell use own use
    print("=" * 50)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    await application.initialize()
# @BLOODYNIGHTMODMENU code not for sell use own use
    await application.start()
# @BLOODYNIGHTMODMENU code not for sell use own use
    await application.updater.start_polling()
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        while True:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await asyncio.sleep(1)
# @BLOODYNIGHTMODMENU code not for sell use own use
    except KeyboardInterrupt:
# @BLOODYNIGHTMODMENU code not for sell use own use
        print("\n Bot stopped!")
# @BLOODYNIGHTMODMENU code not for sell use own use
        await application.updater.stop()
# @BLOODYNIGHTMODMENU code not for sell use own use
        await application.stop()
# @BLOODYNIGHTMODMENU code not for sell use own use
        await application.shutdown()


# @BLOODYNIGHTMODMENU code not for sell use own use
if __name__ == "__main__":
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        asyncio.run(main())
# @BLOODYNIGHTMODMENU code not for sell use own use
    except KeyboardInterrupt:
# @BLOODYNIGHTMODMENU code not for sell use own use
        print("\n Bot stopped by user!")
