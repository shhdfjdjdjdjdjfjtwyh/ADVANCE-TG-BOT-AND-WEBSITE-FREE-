# @BLOODYNIGHTMODMENU code not for sell use own use
import asyncio
# @BLOODYNIGHTMODMENU code not for sell use own use
import os
# @BLOODYNIGHTMODMENU code not for sell use own use
from telethon import TelegramClient, functions
# @BLOODYNIGHTMODMENU code not for sell use own use
from telethon.tl.types import CodeSettings
# @BLOODYNIGHTMODMENU code not for sell use own use
from telethon.errors import (
# @BLOODYNIGHTMODMENU code not for sell use own use
    SessionPasswordNeededError, 
# @BLOODYNIGHTMODMENU code not for sell use own use
    PhoneCodeInvalidError,
# @BLOODYNIGHTMODMENU code not for sell use own use
    PhoneCodeExpiredError,
# @BLOODYNIGHTMODMENU code not for sell use own use
    PhoneNumberInvalidError,
# @BLOODYNIGHTMODMENU code not for sell use own use
    FloodWaitError,
# @BLOODYNIGHTMODMENU code not for sell use own use
    PasswordHashInvalidError,
# @BLOODYNIGHTMODMENU code not for sell use own use
)
# @BLOODYNIGHTMODMENU code not for sell use own use
from config import API_ID, API_HASH

# @BLOODYNIGHTMODMENU code not for sell use own use
SESSIONS_DIR = "sessions"
# @BLOODYNIGHTMODMENU code not for sell use own use
os.makedirs(SESSIONS_DIR, exist_ok=True)


# @BLOODYNIGHTMODMENU code not for sell use own use
async def send_code(phone):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Send OTP code to phone number using Telethon"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        session_name = f"{SESSIONS_DIR}/{phone.replace('+', '')}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        client = TelegramClient(session_name, API_ID, API_HASH)
# @BLOODYNIGHTMODMENU code not for sell use own use
        await client.connect()
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        result = await client(functions.auth.SendCodeRequest(
# @BLOODYNIGHTMODMENU code not for sell use own use
            phone_number=phone,
# @BLOODYNIGHTMODMENU code not for sell use own use
            api_id=API_ID,
# @BLOODYNIGHTMODMENU code not for sell use own use
            api_hash=API_HASH,
# @BLOODYNIGHTMODMENU code not for sell use own use
            settings=CodeSettings()
# @BLOODYNIGHTMODMENU code not for sell use own use
        ))
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {
# @BLOODYNIGHTMODMENU code not for sell use own use
            "success": True,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "phone_code_hash": result.phone_code_hash,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "client": client,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "phone": phone
# @BLOODYNIGHTMODMENU code not for sell use own use
        }
# @BLOODYNIGHTMODMENU code not for sell use own use
    except FloodWaitError as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": f"Too many attempts. Wait {e.seconds} seconds."}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except PhoneNumberInvalidError:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": "Invalid phone number!"}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": str(e)}


# @BLOODYNIGHTMODMENU code not for sell use own use
async def verify_code(client, phone, code, phone_code_hash):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Verify OTP code"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        code = str(code).strip().replace(" ", "")
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        await client(functions.auth.SignInRequest(
# @BLOODYNIGHTMODMENU code not for sell use own use
            phone_number=phone,
# @BLOODYNIGHTMODMENU code not for sell use own use
            phone_code_hash=phone_code_hash,
# @BLOODYNIGHTMODMENU code not for sell use own use
            phone_code=code
# @BLOODYNIGHTMODMENU code not for sell use own use
        ))
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": True, "needs_2fa": False}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except SessionPasswordNeededError:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": True, "needs_2fa": True}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except PhoneCodeInvalidError:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": "Wrong OTP code! Please check again."}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except PhoneCodeExpiredError:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": "OTP expired! Please request a new one."}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        err = str(e).lower()
# @BLOODYNIGHTMODMENU code not for sell use own use
        if "expired" in err:
# @BLOODYNIGHTMODMENU code not for sell use own use
            return {"success": False, "error": "OTP expired! Please request a new one."}
# @BLOODYNIGHTMODMENU code not for sell use own use
        if "invalid" in err:
# @BLOODYNIGHTMODMENU code not for sell use own use
            return {"success": False, "error": "Wrong OTP code!"}
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": str(e)}


# @BLOODYNIGHTMODMENU code not for sell use own use
async def verify_2fa(client, password):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Verify 2FA password - FIXED"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        # ✅ Get password info first
# @BLOODYNIGHTMODMENU code not for sell use own use
        pwd_info = await client(functions.account.GetPasswordRequest())
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # ✅ Use compute_check for proper password hash
# @BLOODYNIGHTMODMENU code not for sell use own use
        from telethon.password import compute_check
# @BLOODYNIGHTMODMENU code not for sell use own use
        password_hash = compute_check(pwd_info, password)
        
# @BLOODYNIGHTMODMENU code not for sell use own use
        # ✅ CheckPassword with proper hash
# @BLOODYNIGHTMODMENU code not for sell use own use
        await client(functions.auth.CheckPasswordRequest(password=password_hash))
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": True}
        
# @BLOODYNIGHTMODMENU code not for sell use own use
    except PasswordHashInvalidError:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": "Wrong 2FA password!"}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except SessionPasswordNeededError:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": "2FA still required. Try again."}
# @BLOODYNIGHTMODMENU code not for sell use own use
    except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        err = str(e).lower()
# @BLOODYNIGHTMODMENU code not for sell use own use
        if "password" in err and "invalid" in err:
# @BLOODYNIGHTMODMENU code not for sell use own use
            return {"success": False, "error": "Wrong 2FA password!"}
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": str(e)}


# @BLOODYNIGHTMODMENU code not for sell use own use
async def resend_code(client, phone, phone_code_hash):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Resend OTP code"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        result = await client(functions.auth.ResendCodeRequest(
# @BLOODYNIGHTMODMENU code not for sell use own use
            phone_number=phone,
# @BLOODYNIGHTMODMENU code not for sell use own use
            phone_code_hash=phone_code_hash
# @BLOODYNIGHTMODMENU code not for sell use own use
        ))
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {
# @BLOODYNIGHTMODMENU code not for sell use own use
            "success": True,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "phone_code_hash": result.phone_code_hash,
# @BLOODYNIGHTMODMENU code not for sell use own use
        }
# @BLOODYNIGHTMODMENU code not for sell use own use
    except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": str(e)}


# @BLOODYNIGHTMODMENU code not for sell use own use
async def get_me(client):
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        me = await client.get_me()
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {
# @BLOODYNIGHTMODMENU code not for sell use own use
            "success": True,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "id": me.id,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "username": me.username,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "first_name": me.first_name,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "last_name": me.last_name,
# @BLOODYNIGHTMODMENU code not for sell use own use
            "phone": me.phone
# @BLOODYNIGHTMODMENU code not for sell use own use
        }
# @BLOODYNIGHTMODMENU code not for sell use own use
    except Exception as e:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return {"success": False, "error": str(e)}


# @BLOODYNIGHTMODMENU code not for sell use own use
async def logout_client(client):
# @BLOODYNIGHTMODMENU code not for sell use own use
    try:
# @BLOODYNIGHTMODMENU code not for sell use own use
        await client.log_out()
# @BLOODYNIGHTMODMENU code not for sell use own use
        await client.disconnect()
# @BLOODYNIGHTMODMENU code not for sell use own use
        return True
# @BLOODYNIGHTMODMENU code not for sell use own use
    except:
# @BLOODYNIGHTMODMENU code not for sell use own use
        try:
# @BLOODYNIGHTMODMENU code not for sell use own use
            await client.disconnect()
# @BLOODYNIGHTMODMENU code not for sell use own use
        except:
# @BLOODYNIGHTMODMENU code not for sell use own use
            pass
# @BLOODYNIGHTMODMENU code not for sell use own use
        return False


# @BLOODYNIGHTMODMENU code not for sell use own use
def format_balance(amount):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return f"₹{amount}"


# @BLOODYNIGHTMODMENU code not for sell use own use
def format_date():
# @BLOODYNIGHTMODMENU code not for sell use own use
    from datetime import datetime
# @BLOODYNIGHTMODMENU code not for sell use own use
    return datetime.now().strftime("%d-%m-%Y %H:%M")


# @BLOODYNIGHTMODMENU code not for sell use own use
def mask_phone(phone):
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not phone or len(phone) < 6:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return phone
# @BLOODYNIGHTMODMENU code not for sell use own use
    return phone[:4] + "*" * (len(phone) - 7) + phone[-3:]


# @BLOODYNIGHTMODMENU code not for sell use own use
def truncate(text, length=30):
# @BLOODYNIGHTMODMENU code not for sell use own use
    if not text:
# @BLOODYNIGHTMODMENU code not for sell use own use
        return ""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return text[:length] + "..." if len(text) > length else text


# @BLOODYNIGHTMODMENU code not for sell use own use
COUNTRY_CODES = {
# @BLOODYNIGHTMODMENU code not for sell use own use
    "US": "+1", "IN": "+91", "UK": "+44", "CA": "+1", "AU": "+61",
# @BLOODYNIGHTMODMENU code not for sell use own use
    "DE": "+49", "FR": "+33", "RU": "+7", "ID": "+62", "PH": "+63",
# @BLOODYNIGHTMODMENU code not for sell use own use
    "BD": "+880", "PK": "+92", "NG": "+234", "BR": "+55", "MX": "+52",
# @BLOODYNIGHTMODMENU code not for sell use own use
    "ZA": "+27", "EG": "+20", "SA": "+966", "AE": "+971", "TR": "+90",
# @BLOODYNIGHTMODMENU code not for sell use own use
    "IT": "+39", "ES": "+34", "NL": "+31", "BE": "+32", "CH": "+41",
# @BLOODYNIGHTMODMENU code not for sell use own use
    "SE": "+46", "NO": "+47", "DK": "+45", "FI": "+358", "PL": "+48",
# @BLOODYNIGHTMODMENU code not for sell use own use
}


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_country_code(country_code):
# @BLOODYNIGHTMODMENU code not for sell use own use
    return COUNTRY_CODES.get(country_code, "")


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# COUNTRY DETECTION FROM PHONE NUMBER
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def detect_country(phone):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """
# @BLOODYNIGHTMODMENU code not for sell use own use
    Detect country from phone number prefix
# @BLOODYNIGHTMODMENU code not for sell use own use
    Returns: (country_code, prefix) or (None, None)
# @BLOODYNIGHTMODMENU code not for sell use own use
    """
# @BLOODYNIGHTMODMENU code not for sell use own use
    phone = phone.replace(" ", "").replace("-", "")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Sort by length (longest first for accurate matching)
# @BLOODYNIGHTMODMENU code not for sell use own use
    sorted_codes = sorted(COUNTRY_CODES.items(), key=lambda x: len(x[1]), reverse=True)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    for code, prefix in sorted_codes:
# @BLOODYNIGHTMODMENU code not for sell use own use
        if phone.startswith(prefix):
# @BLOODYNIGHTMODMENU code not for sell use own use
            return code, prefix
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return None, None


# @BLOODYNIGHTMODMENU code not for sell use own use
def get_country_info(country_code):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Get country flag and name from database"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    from database import get_all_prices
# @BLOODYNIGHTMODMENU code not for sell use own use
    prices = get_all_prices()
# @BLOODYNIGHTMODMENU code not for sell use own use
    info = prices.get(country_code, {})
# @BLOODYNIGHTMODMENU code not for sell use own use
    return {
# @BLOODYNIGHTMODMENU code not for sell use own use
        "flag": info.get("flag", "🌍"),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "name": info.get("name", country_code or "Unknown"),
# @BLOODYNIGHTMODMENU code not for sell use own use
        "price": info.get("price", 0)
# @BLOODYNIGHTMODMENU code not for sell use own use
    }
