# @BLOODYNIGHTMODMENU code not for sell use own use
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
# @BLOODYNIGHTMODMENU code not for sell use own use
from database import get_all_prices

# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# USER SIDE KEYBOARDS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def user_main_menu():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User main menu - GREEN buttons"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("📱 SELL NUM", callback_data="sell_num", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("💰 BALANCE", callback_data="balance", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("💸 WITHDRAW", callback_data="withdraw", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("📜 HISTORY", callback_data="history", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("⏳ PENDING PAY", callback_data="pending_pay", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("💵 PRICES", callback_data="prices", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🆘 SUPPORT", callback_data="support", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def back_menu():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Back button only - RED"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🔙 BACK", callback_data="back_main", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def back_with_refresh(callback):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Back + Refresh"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🔄 Refresh", callback_data=callback, style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🔙 BACK", callback_data="back_main", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def countries_keyboard(page=0, per_page=15):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Countries list - 3 columns, 5 rows + navigation"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    prices = get_all_prices()
# @BLOODYNIGHTMODMENU code not for sell use own use
    items = list(prices.items())
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    start = page * per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    end = start + per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    page_items = items[start:end]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    row = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    for code, info in page_items:
# @BLOODYNIGHTMODMENU code not for sell use own use
        flag = info.get("flag", "🌍")
# @BLOODYNIGHTMODMENU code not for sell use own use
        name = info.get("name", code)[:10]
# @BLOODYNIGHTMODMENU code not for sell use own use
        price = info.get("price", 0)
# @BLOODYNIGHTMODMENU code not for sell use own use
        btn_text = f"{flag} {name} ₹{price}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        row.append(InlineKeyboardButton(btn_text, callback_data=f"sell_{code}", style="success"))
# @BLOODYNIGHTMODMENU code not for sell use own use
        if len(row) == 3:
# @BLOODYNIGHTMODMENU code not for sell use own use
            keyboard.append(row)
# @BLOODYNIGHTMODMENU code not for sell use own use
            row = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    if row:
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append(row)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    # Navigation
# @BLOODYNIGHTMODMENU code not for sell use own use
    nav = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    if page > 0:
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("⬅️", callback_data=f"price_page_{page-1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if end < len(items):
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("➡️", callback_data=f"price_page_{page+1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if nav:
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append(nav)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard.append([InlineKeyboardButton("🏠 MAIN MENU", callback_data="back_main", style="primary")])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup(keyboard)


# @BLOODYNIGHTMODMENU code not for sell use own use
def otp_keyboard():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """OTP verification with resend"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🔄 Resend OTP", callback_data="resend_otp", style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("❌ Cancel", callback_data="cancel_otp", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def two_fa_keyboard():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """2FA password prompt"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("❌ Cancel", callback_data="cancel_otp", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def withdraw_method_keyboard():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Withdraw method selection"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("📱 UPI ID", callback_data="wd_upi", style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🏦 Bank Account", callback_data="wd_bank", style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("💛 Binance ID", callback_data="wd_binance", style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🔴 TRX 20 (Tron)", callback_data="wd_trx20", style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🟡 BEP 20 (BSC)", callback_data="wd_bep20", style="success")],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🔙 BACK", callback_data="back_main", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# ADMIN SIDE KEYBOARDS
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
def admin_main_menu():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Admin main menu"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("➕ ADD CHANNEL", callback_data="add_channel", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("📢 VIEW CHANNELS", callback_data="view_channels", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("👥 VIEW USERS", callback_data="view_users", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🚫 BAN USER", callback_data="ban_user_menu", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("✅ UNBAN USER", callback_data="unban_user_menu", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🆘 SET SUPPORT", callback_data="set_support", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("💵 SET PRICES", callback_data="set_prices", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("📊 STATS", callback_data="admin_stats", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("💸 MIN WITHDRAW", callback_data="set_min_withdraw", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("📜 ALL HISTORY", callback_data="all_history", style="primary"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("⏳ PENDING", callback_data="admin_pending", style="primary")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🔙 BACK", callback_data="back_main", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def users_list_keyboard(users, page=0, per_page=10):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Users list with view buttons"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    items = list(users.items())
# @BLOODYNIGHTMODMENU code not for sell use own use
    start = page * per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    end = start + per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    page_items = items[start:end]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    for uid, u in page_items:
# @BLOODYNIGHTMODMENU code not for sell use own use
        status = "🚫" if u.get("banned") else "✅"
# @BLOODYNIGHTMODMENU code not for sell use own use
        name = u.get("first_name", "User")[:15]
# @BLOODYNIGHTMODMENU code not for sell use own use
        btn_text = f"{status} {name} | ₹{u.get('balance', 0)}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append([InlineKeyboardButton(btn_text, callback_data=f"viewuser_{uid}", style="success")])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    nav = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    if page > 0:
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("⬅️", callback_data=f"user_page_{page-1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if end < len(items):
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("➡️", callback_data=f"user_page_{page+1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if nav:
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append(nav)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard.append([InlineKeyboardButton("🔙 BACK", callback_data="admin_panel", style="danger")])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup(keyboard)


# @BLOODYNIGHTMODMENU code not for sell use own use
def user_detail_keyboard(user_id, is_banned):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """User detail actions"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    if is_banned:
# @BLOODYNIGHTMODMENU code not for sell use own use
        ban_btn = InlineKeyboardButton("✅ UNBAN", callback_data=f"unban_{user_id}", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
    else:
# @BLOODYNIGHTMODMENU code not for sell use own use
        ban_btn = InlineKeyboardButton("🚫 BAN", callback_data=f"ban_{user_id}", style="danger")
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            ban_btn,
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("💰 ADD BAL", callback_data=f"addbal_{user_id}", style="success")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ],
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🔙 BACK", callback_data="view_users", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def channels_list_keyboard(channels):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Channels list with delete buttons"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    for ch in channels:
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append([
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton(f"📢 {ch}", callback_data=f"noop", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("🗑️", callback_data=f"delchannel_{ch}", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ])
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard.append([InlineKeyboardButton("➕ ADD NEW", callback_data="add_channel", style="success")])
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard.append([InlineKeyboardButton("🔙 BACK", callback_data="admin_panel", style="danger")])
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup(keyboard)


# @BLOODYNIGHTMODMENU code not for sell use own use
def prices_admin_keyboard(page=0, per_page=15):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Admin prices - set price per country"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    prices = get_all_prices()
# @BLOODYNIGHTMODMENU code not for sell use own use
    items = list(prices.items())
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    start = page * per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    end = start + per_page
# @BLOODYNIGHTMODMENU code not for sell use own use
    page_items = items[start:end]
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    row = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    for code, info in page_items:
# @BLOODYNIGHTMODMENU code not for sell use own use
        flag = info.get("flag", "🌍")
# @BLOODYNIGHTMODMENU code not for sell use own use
        name = info.get("name", code)[:8]
# @BLOODYNIGHTMODMENU code not for sell use own use
        price = info.get("price", 0)
# @BLOODYNIGHTMODMENU code not for sell use own use
        btn_text = f"{flag} {name} ₹{price}"
# @BLOODYNIGHTMODMENU code not for sell use own use
        row.append(InlineKeyboardButton(btn_text, callback_data=f"editprice_{code}", style="success"))
# @BLOODYNIGHTMODMENU code not for sell use own use
        if len(row) == 2:
# @BLOODYNIGHTMODMENU code not for sell use own use
            keyboard.append(row)
# @BLOODYNIGHTMODMENU code not for sell use own use
            row = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    if row:
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append(row)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    nav = []
# @BLOODYNIGHTMODMENU code not for sell use own use
    if page > 0:
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("⬅️", callback_data=f"adminprice_page_{page-1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if end < len(items):
# @BLOODYNIGHTMODMENU code not for sell use own use
        nav.append(InlineKeyboardButton("➡️", callback_data=f"adminprice_page_{page+1}", style="danger"))
# @BLOODYNIGHTMODMENU code not for sell use own use
    if nav:
# @BLOODYNIGHTMODMENU code not for sell use own use
        keyboard.append(nav)
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    keyboard.append([InlineKeyboardButton("🔙 BACK", callback_data="admin_panel", style="danger")])
    
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup(keyboard)


# @BLOODYNIGHTMODMENU code not for sell use own use
def pending_payment_keyboard(order_id):
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Admin pending payment approve/reject"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("✅ APPROVE", callback_data=f"approve_{order_id}", style="success"),
# @BLOODYNIGHTMODMENU code not for sell use own use
            InlineKeyboardButton("❌ REJECT", callback_data=f"reject_{order_id}", style="danger")
# @BLOODYNIGHTMODMENU code not for sell use own use
        ]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])


# @BLOODYNIGHTMODMENU code not for sell use own use
def support_back():
# @BLOODYNIGHTMODMENU code not for sell use own use
    """Support back button"""
# @BLOODYNIGHTMODMENU code not for sell use own use
    return InlineKeyboardMarkup([
# @BLOODYNIGHTMODMENU code not for sell use own use
        [InlineKeyboardButton("🔙 BACK", callback_data="back_main", style="danger")]
# @BLOODYNIGHTMODMENU code not for sell use own use
    ])
