# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================
# @BLOODYNIGHTMODMENU code not for sell use own use
# NUMBER SELL BOT - CONFIGURATION
# @BLOODYNIGHTMODMENU code not for sell use own use
# ============================================

# @BLOODYNIGHTMODMENU code not for sell use own use
BOT_TOKEN = ""
# @BLOODYNIGHTMODMENU code not for sell use own use
ADMIN_ID = 

# @BLOODYNIGHTMODMENU code not for sell use own use
DATA_FILE = "data.json"

# @BLOODYNIGHTMODMENU code not for sell use own use
# Telethon API (my.telegram.org se lo)
# @BLOODYNIGHTMODMENU code not for sell use own use
API_ID = 
# @BLOODYNIGHTMODMENU code not for sell use own use
API_HASH = ""

# @BLOODYNIGHTMODMENU code not for sell use own use
# Support

# @BLOODYNIGHTMODMENU code not for sell use own use
# Minimum withdrawal amount
# @BLOODYNIGHTMODMENU code not for sell use own use
MIN_WITHDRAW = 50
